def add(a: int, b: int, c: int = 0) -> int:
    return a + b + c
