package plugin_manager

import (
	"os"
	"path/filepath"

	"github.com/langgenius/dify-plugin-daemon/internal/utils/log"
	"github.com/langgenius/dify-plugin-daemon/pkg/entities/plugin_entities"
)

// UninstallFromLocal uninstalls a plugin from local storage
// once deleted, local runtime will automatically shutdown and exit after several time
func (p *PluginManager) UninstallFromLocal(identity plugin_entities.PluginUniqueIdentifier) error {
	if err := p.installedBucket.Delete(identity); err != nil {
		return err
	}

	// send shutdown runtime
	runtime, ok := p.m.Load(identity.String())
	if ok {
		runtime.Stop()
	}

	// Clean up working directory (including .venv, __pycache__, etc.)
	workingPath := filepath.Join(p.config.PluginWorkingPath, identity.String())
	if _, err := os.Stat(workingPath); err == nil {
		log.Info("cleaning up plugin working directory: %s", workingPath)
		if err := os.RemoveAll(workingPath); err != nil {
			log.Warn("failed to remove working path %s: %s", workingPath, err)
		} else {
			log.Info("successfully removed plugin working directory: %s", workingPath)
		}
	}

	return nil
}
