package controllers

import (
	"runtime"

	"github.com/gin-gonic/gin"
	"github.com/langgenius/dify-plugin-daemon/internal/core/plugin_manager"
	"github.com/langgenius/dify-plugin-daemon/internal/core/session_manager"
	"github.com/langgenius/dify-plugin-daemon/internal/db"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/log"
	"github.com/langgenius/dify-plugin-daemon/pkg/entities/plugin_entities"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
	// Custom registry to avoid default Go runtime and promhttp metrics
	customRegistry = prometheus.NewRegistry()

	// Health status metrics
	healthStatus = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_up",
		Help: "Service health status (1 = healthy, 0 = unhealthy)",
	})

	databaseHealthStatus = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_database_up",
		Help: "Database connection health status (1 = healthy, 0 = unhealthy)",
	})

	pluginManagerHealthStatus = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_plugin_manager_up",
		Help: "Plugin manager health status (1 = healthy, 0 = unhealthy)",
	})

	// Memory metrics
	memoryAllocBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_memory_alloc_bytes",
		Help: "Number of bytes allocated and currently in use",
	})

	memorySysBytes = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_memory_sys_bytes",
		Help: "Total bytes of memory obtained from the OS",
	})

	// GC metrics
	gcTotal = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_gc_total",
		Help: "Total number of completed GC cycles",
	})

	// Goroutine metrics
	goroutines = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_goroutines",
		Help: "Number of goroutines currently running",
	})

	// Application-specific metrics
	activeSessions = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_active_sessions",
		Help: "Number of active sessions",
	})

	loadedPlugins = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_loaded_plugins",
		Help: "Number of loaded plugins",
	})

	databaseConnections = prometheus.NewGauge(prometheus.GaugeOpts{
		Name: "dify_plugin_daemon_database_connections",
		Help: "Number of active database connections",
	})
)

func init() {
	// Register all metrics with our custom registry (not the default one)
	// This prevents Go runtime and promhttp metrics from being exposed
	// Health status metrics
	customRegistry.MustRegister(healthStatus)
	customRegistry.MustRegister(databaseHealthStatus)
	customRegistry.MustRegister(pluginManagerHealthStatus)

	// Runtime metrics
	customRegistry.MustRegister(memoryAllocBytes)
	customRegistry.MustRegister(memorySysBytes)
	customRegistry.MustRegister(gcTotal)
	customRegistry.MustRegister(goroutines)

	// Application metrics
	customRegistry.MustRegister(activeSessions)
	customRegistry.MustRegister(loadedPlugins)
	customRegistry.MustRegister(databaseConnections)
}

// checkDatabaseHealth checks if database connection is healthy
func checkDatabaseHealth() bool {
	if db.DifyPluginDB == nil {
		return false
	}

	sqlDB, err := db.DifyPluginDB.DB()
	if err != nil {
		log.Warn("[WARN][CLOG][SYS] failed to get database connection: %v", err)
		return false
	}

	// Ping database to verify connection
	if err := sqlDB.Ping(); err != nil {
		log.Warn("[WARN][CLOG][SYS] database ping failed: %v", err)
		return false
	}

	return true
}

// checkPluginManagerHealth checks if plugin manager is healthy
func checkPluginManagerHealth() bool {
	manager := plugin_manager.Manager()
	if manager == nil {
		return false
	}
	return true
}

// updateMetrics collects current runtime metrics and updates Prometheus gauges
func updateMetrics() {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)

	// Check component health
	isDatabaseHealthy := checkDatabaseHealth()
	isPluginManagerHealthy := checkPluginManagerHealth()

	// Overall health: healthy if all critical components are healthy
	overallHealthy := isDatabaseHealthy && isPluginManagerHealthy

	// Update health status metrics
	if overallHealthy {
		healthStatus.Set(1)
	} else {
		healthStatus.Set(0)
	}

	if isDatabaseHealthy {
		databaseHealthStatus.Set(1)
	} else {
		databaseHealthStatus.Set(0)
	}

	if isPluginManagerHealthy {
		pluginManagerHealthStatus.Set(1)
	} else {
		pluginManagerHealthStatus.Set(0)
	}

	// Update memory metrics
	memoryAllocBytes.Set(float64(m.Alloc))
	memorySysBytes.Set(float64(m.Sys))

	// Update GC metrics
	gcTotal.Set(float64(m.NumGC))

	// Update goroutine count
	goroutines.Set(float64(runtime.NumGoroutine()))

	// Update active sessions count
	activeSessions.Set(float64(session_manager.GetAllSessionsCount()))

	// Update loaded plugins count
	if manager := plugin_manager.Manager(); manager != nil {
		count := 0
		manager.GetPluginMap().Range(func(key string, value plugin_entities.PluginLifetime) bool {
			count++
			return true
		})
		loadedPlugins.Set(float64(count))
	} else {
		loadedPlugins.Set(0)
	}

	// Update database connections count
	if isDatabaseHealthy {
		sqlDB, err := db.DifyPluginDB.DB()
		if err == nil {
			stats := sqlDB.Stats()
			databaseConnections.Set(float64(stats.InUse))
		}
	} else {
		databaseConnections.Set(0)
	}
}

// PrometheusMetrics is a Gin handler that exposes metrics in Prometheus format
func PrometheusMetrics(c *gin.Context) {
	// Update metrics before exposing them
	updateMetrics()

	// Use the custom registry handler to only expose our business metrics
	// This prevents Go runtime (go_*) and promhttp (promhttp_*) metrics from being exposed
	promhttp.HandlerFor(customRegistry, promhttp.HandlerOpts{}).ServeHTTP(c.Writer, c.Request)
}
