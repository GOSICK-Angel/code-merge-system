package plugin_manager

import (
	"os"
	"path/filepath"
	"time"

	"github.com/langgenius/dify-plugin-daemon/internal/core/plugin_manager/media_transport"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/log"
	"github.com/langgenius/dify-plugin-daemon/pkg/entities/plugin_entities"
)

const (
	// GARBAGE_COLLECTOR_INTERVAL is the interval for running garbage collection
	GARBAGE_COLLECTOR_INTERVAL = 1 * time.Hour
)

// GarbageCollector manages cleanup of orphaned plugin files
type GarbageCollector struct {
	installedBucket *media_transport.InstalledBucket
	workingPath     string
	stopped         bool
}

// NewGarbageCollector creates a new garbage collector instance
func NewGarbageCollector(installedBucket *media_transport.InstalledBucket, workingPath string) *GarbageCollector {
	return &GarbageCollector{
		installedBucket: installedBucket,
		workingPath:     workingPath,
		stopped:         false,
	}
}

// Start begins the garbage collection loop
func (gc *GarbageCollector) Start() {
	log.Info("starting garbage collector for orphaned plugin files")
	ticker := time.NewTicker(GARBAGE_COLLECTOR_INTERVAL)
	defer ticker.Stop()

	// Run once immediately on startup
	gc.cleanOrphanedFiles()

	for !gc.stopped {
		select {
		case <-ticker.C:
			gc.cleanOrphanedFiles()
		}
	}
}

// Stop stops the garbage collector
func (gc *GarbageCollector) Stop() {
	gc.stopped = true
}

// cleanOrphanedFiles removes working directories for plugins that are no longer installed
func (gc *GarbageCollector) cleanOrphanedFiles() {
	log.Info("running garbage collection for orphaned plugin files")

	// Get list of installed plugins
	installedPlugins, err := gc.installedBucket.List()
	if err != nil {
		log.Error("failed to list installed plugins during garbage collection: %s", err)
		return
	}

	// Build map of installed plugin identifiers for quick lookup
	installedMap := make(map[string]bool)
	for _, plugin := range installedPlugins {
		installedMap[plugin.String()] = true
	}

	// Check if working path exists
	if _, err := os.Stat(gc.workingPath); os.IsNotExist(err) {
		log.Info("working path %s does not exist, skipping garbage collection", gc.workingPath)
		return
	}

	// Scan working directory for orphaned files
	entries, err := os.ReadDir(gc.workingPath)
	if err != nil {
		log.Error("failed to read working directory during garbage collection: %s", err)
		return
	}

	orphanedCount := 0
	for _, entry := range entries {
		if !entry.IsDir() {
			continue
		}

		// Skip hidden directories
		if len(entry.Name()) > 0 && entry.Name()[0] == '.' {
			continue
		}

		// Check if this directory corresponds to an installed plugin
		_, err := plugin_entities.NewPluginUniqueIdentifier(entry.Name())
		if err != nil {
			// Not a valid plugin identifier, skip
			continue
		}

		if !installedMap[entry.Name()] {
			// This is an orphaned directory
			orphanedPath := filepath.Join(gc.workingPath, entry.Name())
			log.Info("found orphaned plugin directory: %s", orphanedPath)

			if err := os.RemoveAll(orphanedPath); err != nil {
				log.Error("failed to remove orphaned directory %s: %s", orphanedPath, err)
			} else {
				log.Info("successfully removed orphaned directory: %s", orphanedPath)
				orphanedCount++
			}
		}
	}

	if orphanedCount > 0 {
		log.Info("garbage collection completed: removed %d orphaned plugin directories", orphanedCount)
	} else {
		log.Info("garbage collection completed: no orphaned directories found")
	}
}

