package local_runtime

import (
	"bytes"
	"context"
	_ "embed"
	"fmt"
	"os"
	"os/exec"
	"path"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	version "github.com/hashicorp/go-version"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/log"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/routine"
)

// Global semaphore to limit concurrent dependency installations
// This prevents OOM when multiple plugins download large packages simultaneously
var (
	dependencyInstallSem  chan struct{}
	dependencyInstallOnce sync.Once
)

func initDependencyInstallSemaphore(maxConcurrentInstalls int) {
	dependencyInstallOnce.Do(func() {
		// Default to 1 if not configured or invalid
		if maxConcurrentInstalls <= 0 {
			maxConcurrentInstalls = 1
		}
		dependencyInstallSem = make(chan struct{}, maxConcurrentInstalls)
		log.Info("initialized dependency installation semaphore with max concurrent installs: %d", maxConcurrentInstalls)
		if maxConcurrentInstalls == 1 {
			log.Warn("dependency installation limited to 1 concurrent install to prevent OOM. If you see 'signal: killed' errors, check container memory limits (recommend 4GB+)")
		}
	})
}

//go:embed patches/0.0.1b70.ai_model.py.patch
var python001b70aiModelsPatches []byte

//go:embed patches/0.1.1.llm.py.patch
var python011llmPatches []byte

//go:embed patches/0.1.1.request_reader.py.patch
var python011requestReaderPatches []byte

func (p *LocalPluginRuntime) InitPythonEnvironment() error {
	// check if virtual environment exists
	if _, err := os.Stat(path.Join(p.State.WorkingPath, ".venv")); err == nil {
		// check if venv is valid, try to find .venv/dify/plugin.json
		if _, err := os.Stat(path.Join(p.State.WorkingPath, ".venv/dify/plugin.json")); err != nil {
			// remove the venv and rebuild it
			os.RemoveAll(path.Join(p.State.WorkingPath, ".venv"))
		} else {
			// patch requirements.txt to fix common compatibility issues
			requirementsPath := path.Join(p.State.WorkingPath, "requirements.txt")
			needsRebuild, err := p.patchRequirements(requirementsPath)
			if err != nil {
				log.Warn("failed to patch requirements.txt: %s", err)
			}

			// if requirements were modified, rebuild the virtual environment to ensure correct versions
			if needsRebuild {
				log.Info("requirements.txt was patched, rebuilding virtual environment for %s", p.Config.Identity())
				os.RemoveAll(path.Join(p.State.WorkingPath, ".venv"))
				// fall through to rebuild venv below
			} else {
				// setup python interpreter path
				pythonPath, err := filepath.Abs(path.Join(p.State.WorkingPath, ".venv/bin/python"))
				if err != nil {
					return fmt.Errorf("failed to find python: %s", err)
				}
				p.pythonInterpreterPath = pythonPath

				// PATCH:
				//  plugin sdk version less than 0.0.1b70 contains a memory leak bug
				//  to reach a better user experience, we will patch it here using a patched file
				// https://github.com/langgenius/dify-plugin-sdks/commit/161045b65f708d8ef0837da24440ab3872821b3b
				if err := p.patchPluginSdk(path.Join(p.State.WorkingPath, "requirements.txt")); err != nil {
					log.Error("failed to patch the plugin sdk: %s", err)
				}
				return nil
			}
		}
	}

	// execute init command, create a virtual environment
	success := false

	var uvPath string
	if p.uvPath != "" {
		uvPath = p.uvPath
	} else {
		// using `from uv._find_uv import find_uv_bin; print(find_uv_bin())` to find uv path
		cmd := exec.Command(p.defaultPythonInterpreterPath, "-c", "from uv._find_uv import find_uv_bin; print(find_uv_bin())")
		cmd.Dir = p.State.WorkingPath
		output, err := cmd.Output()
		if err != nil {
			return fmt.Errorf("failed to find uv path: %s", err)
		}
		uvPath = strings.TrimSpace(string(output))
	}

	cmd := exec.Command(uvPath, "venv", ".venv", "--python", "3.12")
	cmd.Dir = p.State.WorkingPath
	b := bytes.NewBuffer(nil)
	cmd.Stdout = b
	cmd.Stderr = b
	if err := cmd.Run(); err != nil {
		return fmt.Errorf("failed to create virtual environment: %s, output: %s", err, b.String())
	}
	defer func() {
		// if init failed, remove the .venv directory
		if !success {
			os.RemoveAll(path.Join(p.State.WorkingPath, ".venv"))
		} else {
			// create dify/plugin.json
			pluginJsonPath := path.Join(p.State.WorkingPath, ".venv/dify/plugin.json")
			os.MkdirAll(path.Dir(pluginJsonPath), 0755)
			os.WriteFile(pluginJsonPath, []byte(fmt.Sprintf(`{"timestamp":%d}`, time.Now().Unix())), 0644)
		}
	}()

	pythonPath, err := filepath.Abs(path.Join(p.State.WorkingPath, ".venv/bin/python"))
	if err != nil {
		return fmt.Errorf("failed to find python: %s", err)
	}

	if _, err := os.Stat(pythonPath); err != nil {
		return fmt.Errorf("failed to find python: %s", err)
	}

	p.pythonInterpreterPath = pythonPath

	// try find requirements.txt
	requirementsPath := path.Join(p.State.WorkingPath, "requirements.txt")
	if _, err := os.Stat(requirementsPath); err != nil {
		return fmt.Errorf("failed to find requirements.txt: %s", err)
	}

	// patch requirements.txt to fix common compatibility issues
	_, err = p.patchRequirements(requirementsPath)
	if err != nil {
		log.Warn("failed to patch requirements.txt: %s", err)
	}

	log.Info("starting dependency installation for %s (timeout: %ds)", p.Config.Identity(), p.pythonEnvInitTimeout)

	// Initialize and acquire dependency installation semaphore to prevent OOM
	initDependencyInstallSemaphore(p.pluginMaxConcurrentInstalls)
	log.Info("waiting for dependency installation slot for %s", p.Config.Identity())
	dependencyInstallSem <- struct{}{}
	defer func() {
		<-dependencyInstallSem
		log.Info("released dependency installation slot for %s", p.Config.Identity())
	}()
	log.Info("acquired dependency installation slot for %s, starting installation", p.Config.Identity())

	// install dependencies with timeout based on configuration
	installTimeout := time.Duration(p.pythonEnvInitTimeout) * time.Second
	// Ensure minimum timeout of 10 minutes for large dependencies (scipy 34MB, pymupdf 19MB)
	// These packages take significant time to download and install
	if installTimeout < 10*time.Minute {
		installTimeout = 10 * time.Minute
	}
	ctx, cancel := context.WithTimeout(context.Background(), installTimeout)
	defer cancel()

	args := []string{"install"}

	if p.pipMirrorUrl != "" {
		args = append(args, "-i", p.pipMirrorUrl)
	}

	args = append(args, "-r", "requirements.txt")

	if !p.pipPreferBinary {
		log.Warn("PIP_PREFER_BINARY is disabled, but uv always prefers binary packages by default")
	}

	if p.pipVerbose {
		args = append(args, "-vvv")
	}

	if p.pipExtraArgs != "" {
		args = append(args, strings.Split(p.pipExtraArgs, " ")...)
	}

	args = append([]string{"pip"}, args...)

	virtualEnvPath := path.Join(p.State.WorkingPath, ".venv")
	cmd = exec.CommandContext(ctx, uvPath, args...)
	cmd.Env = os.Environ()
	cmd.Env = append(cmd.Env, "VIRTUAL_ENV="+virtualEnvPath)
	cmd.Env = append(cmd.Env, "CFLAGS=-I/usr/include -O2")
	cmd.Env = append(cmd.Env, "LDFLAGS=-L/usr/lib")
	if p.HttpProxy != "" {
		cmd.Env = append(cmd.Env, fmt.Sprintf("HTTP_PROXY=%s", p.HttpProxy))
	}
	if p.HttpsProxy != "" {
		cmd.Env = append(cmd.Env, fmt.Sprintf("HTTPS_PROXY=%s", p.HttpsProxy))
	}
	if p.NoProxy != "" {
		cmd.Env = append(cmd.Env, fmt.Sprintf("NO_PROXY=%s", p.NoProxy))
	}
	cmd.Dir = p.State.WorkingPath

	// get stdout and stderr
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return fmt.Errorf("failed to get stdout: %s", err)
	}
	defer stdout.Close()

	stderr, err := cmd.StderrPipe()
	if err != nil {
		return fmt.Errorf("failed to get stderr: %s", err)
	}
	defer stderr.Close()

	// start command
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("failed to start command: %s", err)
	}
	defer func() {
		if cmd.Process != nil {
			cmd.Process.Kill()
		}
	}()

	var errMsg strings.Builder
	var wg sync.WaitGroup
	wg.Add(2)

	lastActiveAt := time.Now()

	routine.Submit(map[string]string{
		"module":   "plugin_manager",
		"function": "InitPythonEnvironment",
	}, func() {
		defer wg.Done()
		// read stdout
		buf := make([]byte, 1024)
		for {
			n, err := stdout.Read(buf)
			if err != nil {
				break
			}
			if n > 0 {
				output := string(buf[:n])
				log.Info("installing dependencies for %s - %s", p.Config.Identity(), output)
				lastActiveAt = time.Now()
			}
		}
	})

	routine.Submit(map[string]string{
		"module":   "plugin_manager",
		"function": "InitPythonEnvironment",
	}, func() {
		defer wg.Done()
		// read stderr
		buf := make([]byte, 1024)
		for {
			n, err := stderr.Read(buf)
			if err != nil && err != os.ErrClosed {
				if n > 0 {
					output := string(buf[:n])
					errMsg.WriteString(output)
					log.Warn("dependency installation warning for %s: %s", p.Config.Identity(), output)
				}
				lastActiveAt = time.Now()
				break
			} else if err == os.ErrClosed {
				break
			}

			if n > 0 {
				output := string(buf[:n])
				errMsg.WriteString(output)
				lastActiveAt = time.Now()
			}
		}
	})

	routine.Submit(map[string]string{
		"module":   "plugin_manager",
		"function": "InitPythonEnvironment",
	}, func() {
		ticker := time.NewTicker(5 * time.Second)
		defer ticker.Stop()
		inactivityTimeout := time.Duration(p.pythonEnvInitTimeout) * time.Second
		// Allow longer inactivity period for downloading large packages (scipy 34MB can take minutes)
		// Use the larger of configured timeout or 10 minutes
		if inactivityTimeout < 10*time.Minute {
			inactivityTimeout = 10 * time.Minute
		}

		for range ticker.C {
			if cmd.ProcessState != nil && cmd.ProcessState.Exited() {
				break
			}

			inactiveDuration := time.Since(lastActiveAt)
			if inactiveDuration > inactivityTimeout {
				cmd.Process.Kill()
				errMsg.WriteString(fmt.Sprintf("init process exited due to no activity for %d seconds, retrying", int(inactiveDuration.Seconds())))
				break
			}
		}
	})

	wg.Wait()

	if err := cmd.Wait(); err != nil {
		fullError := errMsg.String()
		if len(fullError) > 1000 {
			// Truncate very long error messages but keep the most relevant parts
			fullError = fullError[:500] + "\n...[truncated]...\n" + fullError[len(fullError)-500:]
		}
		return fmt.Errorf("failed to install dependencies: %s, output: %s", err, fullError)
	}

	log.Info("successfully installed dependencies for %s", p.Config.Identity())

	// Optimize pre-compilation: only compile plugin code, exclude .venv to dramatically reduce init time
	// This reduces compilation from ~30s per plugin to ~1s while maintaining performance benefits
	if p.pythonCompileAllExtraArgs != "skip" {
		compileArgs := []string{"-m", "compileall", "-q"} // -q for quiet mode to reduce log spam

		// Exclude .venv directory and only compile plugin source code
		// This prevents recompiling hundreds of MB of dependencies for each plugin
		compileArgs = append(compileArgs, "-x", ".venv")

		if p.pythonCompileAllExtraArgs != "" && p.pythonCompileAllExtraArgs != "skip" {
			compileArgs = append(compileArgs, strings.Split(p.pythonCompileAllExtraArgs, " ")...)
		}
		compileArgs = append(compileArgs, ".")

		log.Info("pre-compiling plugin code for %s (excluding dependencies)", p.Config.Identity())

		// pre-compile the plugin to avoid costly compilation on first invocation
		compileCmd := exec.CommandContext(ctx, pythonPath, compileArgs...)
		compileCmd.Dir = p.State.WorkingPath

		// get stdout and stderr
		compileStdout, err := compileCmd.StdoutPipe()
		if err != nil {
			return fmt.Errorf("failed to get stdout: %s", err)
		}
		defer compileStdout.Close()

		compileStderr, err := compileCmd.StderrPipe()
		if err != nil {
			return fmt.Errorf("failed to get stderr: %s", err)
		}
		defer compileStderr.Close()

		// start command
		if err := compileCmd.Start(); err != nil {
			return fmt.Errorf("failed to start command: %s", err)
		}
		defer func() {
			if compileCmd.Process != nil {
				compileCmd.Process.Kill()
			}
		}()

		var compileErrMsg strings.Builder
		var compileWg sync.WaitGroup
		compileWg.Add(2)

		routine.Submit(map[string]string{
			"module":   "plugin_manager",
			"function": "InitPythonEnvironment",
		}, func() {
			defer compileWg.Done()
			// read compileStdout (now much less output due to -q flag and .venv exclusion)
			for {
				buf := make([]byte, 102400)
				n, err := compileStdout.Read(buf)
				if err != nil {
					break
				}
				// Only log if there's actual output (errors or warnings)
				output := strings.TrimSpace(string(buf[:n]))
				if len(output) > 0 {
					log.Info("pre-compiling %s - %s", p.Config.Identity(), output)
				}
			}
		})

		routine.Submit(map[string]string{
			"module":   "plugin_manager",
			"function": "InitPythonEnvironment",
		}, func() {
			defer compileWg.Done()
			// read stderr
			buf := make([]byte, 1024)
			for {
				n, err := compileStderr.Read(buf)
				if err != nil {
					break
				}
				compileErrMsg.WriteString(string(buf[:n]))
			}
		})

		compileWg.Wait()
		if err := compileCmd.Wait(); err != nil {
			// skip the error if the plugin is not compiled
			// ISSUE: for some weird reasons, plugins may reference to a broken sdk but it works well itself
			// we need to skip it but log the messages
			// https://github.com/langgenius/dify/issues/16292
			log.Warn("failed to pre-compile the plugin: %s", compileErrMsg.String())
		}
	} else {
		log.Info("skipping pre-compilation for %s (PYTHON_COMPILE_ALL_EXTRA_ARGS=skip)", p.Config.Identity())
	}

	log.Info("pre-loaded the plugin %s", p.Config.Identity())

	// import dify_plugin to speedup the first launching
	// ISSUE: it takes too long to setup all the deps, that's why we choose to preload it
	importCmd := exec.CommandContext(ctx, pythonPath, "-c", "import dify_plugin")
	importCmd.Dir = p.State.WorkingPath
	importCmd.Output()

	// PATCH:
	//  plugin sdk version less than 0.0.1b70 contains a memory leak bug
	//  to reach a better user experience, we will patch it here using a patched file
	// https://github.com/langgenius/dify-plugin-sdks/commit/161045b65f708d8ef0837da24440ab3872821b3b
	if err := p.patchPluginSdk(requirementsPath); err != nil {
		log.Error("failed to patch the plugin sdk: %s", err)
	}

	success = true

	return nil
}

func (p *LocalPluginRuntime) patchPluginSdk(requirementsPath string) error {
	// get the version of the plugin sdk
	requirements, err := os.ReadFile(requirementsPath)
	if err != nil {
		return fmt.Errorf("failed to read requirements.txt: %s", err)
	}

	pluginSdkVersion, err := p.getPluginSdkVersion(string(requirements))
	if err != nil {
		log.Error("failed to get the version of the plugin sdk: %s", err)
		return nil
	}

	pluginSdkVersionObj, err := version.NewVersion(pluginSdkVersion)
	if err != nil {
		log.Error("failed to create the version: %s", err)
		return nil
	}

	if pluginSdkVersionObj.LessThan(version.Must(version.NewVersion("0.0.1b70"))) {
		// get dify-plugin path
		command := exec.Command(p.pythonInterpreterPath, "-c", "import importlib.util;print(importlib.util.find_spec('dify_plugin').origin)")
		command.Dir = p.State.WorkingPath
		output, err := command.Output()
		if err != nil {
			return fmt.Errorf("failed to get the path of the plugin sdk: %s", err)
		}

		pluginSdkPath := path.Dir(strings.TrimSpace(string(output)))
		patchPath := path.Join(pluginSdkPath, "interfaces/model/ai_model.py")

		// apply the patch
		if _, err := os.Stat(patchPath); err != nil {
			return fmt.Errorf("failed to find the patch file: %s", err)
		}

		if err := os.WriteFile(patchPath, python001b70aiModelsPatches, 0644); err != nil {
			return fmt.Errorf("failed to write the patch file: %s", err)
		}
	}

	if pluginSdkVersionObj.LessThan(version.Must(version.NewVersion("0.1.1"))) {
		// get dify-plugin path
		command := exec.Command(p.pythonInterpreterPath, "-c", "import importlib.util;print(importlib.util.find_spec('dify_plugin').origin)")
		command.Dir = p.State.WorkingPath
		output, err := command.Output()
		if err != nil {
			return fmt.Errorf("failed to get the path of the plugin sdk: %s", err)
		}

		pluginSdkPath := path.Dir(strings.TrimSpace(string(output)))
		patchPath := path.Join(pluginSdkPath, "entities/model/llm.py")

		// apply the patch
		if _, err := os.Stat(patchPath); err != nil {
			return fmt.Errorf("failed to find the patch file: %s", err)
		}

		if err := os.WriteFile(patchPath, python011llmPatches, 0644); err != nil {
			return fmt.Errorf("failed to write the patch file: %s", err)
		}

		patchPath = path.Join(pluginSdkPath, "core/server/stdio/request_reader.py")
		if _, err := os.Stat(patchPath); err != nil {
			return fmt.Errorf("failed to find the patch file: %s", err)
		}

		if err := os.WriteFile(patchPath, python011requestReaderPatches, 0644); err != nil {
			return fmt.Errorf("failed to write the patch file: %s", err)
		}
	}
	return nil
}

// patchRequirements patches the requirements.txt file to fix common compatibility issues
// Returns (needsRebuild, error) where needsRebuild indicates if the virtual environment should be rebuilt
func (p *LocalPluginRuntime) patchRequirements(requirementsPath string) (bool, error) {
	content, err := os.ReadFile(requirementsPath)
	if err != nil {
		return false, fmt.Errorf("failed to read requirements.txt: %s", err)
	}

	lines := strings.Split(string(content), "\n")
	modified := false
	hasNumpy := false
	numpyVersionConstrained := false
	hasGevent := false
	geventVersionConstrained := false

	// check if numpy and gevent are in requirements and if they have version constraints
	for i, line := range lines {
		trimmedLine := strings.TrimSpace(line)
		if trimmedLine == "" || strings.HasPrefix(trimmedLine, "#") {
			continue
		}

		// check if this line contains numpy
		numpyRe := regexp.MustCompile(`^numpy([>=<~!]|$)`)
		if numpyRe.MatchString(trimmedLine) {
			hasNumpy = true

			// check if numpy has version constraint that limits it below 2.0
			if strings.Contains(trimmedLine, "<2") || strings.Contains(trimmedLine, "<2.0") {
				numpyVersionConstrained = true
			} else if strings.Contains(trimmedLine, "==") {
				// check if pinned version is less than 2.0
				versionRe := regexp.MustCompile(`numpy==([0-9.]+)`)
				matches := versionRe.FindStringSubmatch(trimmedLine)
				if len(matches) >= 2 {
					v, err := version.NewVersion(matches[1])
					if err == nil {
						constraint, _ := version.NewConstraint("< 2.0")
						if constraint.Check(v) {
							numpyVersionConstrained = true
						}
					}
				}
			}

			// if numpy doesn't have proper version constraint, add it
			if !numpyVersionConstrained {
				// replace or add version constraint
				if strings.Contains(trimmedLine, ">=") || strings.Contains(trimmedLine, ">") {
					// add upper bound constraint
					if !strings.Contains(trimmedLine, ",") {
						lines[i] = trimmedLine + ",<2.0"
					} else {
						lines[i] = trimmedLine + ",<2.0"
					}
				} else if strings.Contains(trimmedLine, "==") {
					// already has exact version, check if it's >= 2.0
					versionRe := regexp.MustCompile(`numpy==([0-9.]+)`)
					matches := versionRe.FindStringSubmatch(trimmedLine)
					if len(matches) >= 2 {
						v, err := version.NewVersion(matches[1])
						if err == nil {
							constraint, _ := version.NewConstraint(">= 2.0")
							if constraint.Check(v) {
								// replace with safe version
								lines[i] = "numpy>=1.20.0,<2.0"
								log.Warn("numpy version >= 2.0 detected, downgrading to <2.0 for compatibility")
							}
						}
					}
				} else {
					// no version constraint, add one
					lines[i] = "numpy>=1.20.0,<2.0"
					log.Info("adding numpy version constraint (<2.0) for compatibility")
				}
				modified = true
				numpyVersionConstrained = true
			}
		}

		// check if this line contains gevent
		// gevent 在 Python 3.12 上需要 >= 24.0.0 以确保 C 扩展兼容性
		geventRe := regexp.MustCompile(`^gevent([>=<~!]|$)`)
		if geventRe.MatchString(trimmedLine) {
			hasGevent = true

			// check if gevent has version constraint that ensures compatibility with Python 3.12
			// gevent >= 24.0.0 提供了对 Python 3.12 的完整支持
			if strings.Contains(trimmedLine, ">=24") || strings.Contains(trimmedLine, "==24") ||
				strings.Contains(trimmedLine, ">24") {
				geventVersionConstrained = true
			} else if strings.Contains(trimmedLine, "==") {
				// check if pinned version is >= 24.0.0
				versionRe := regexp.MustCompile(`gevent==([0-9.]+)`)
				matches := versionRe.FindStringSubmatch(trimmedLine)
				if len(matches) >= 2 {
					v, err := version.NewVersion(matches[1])
					if err == nil {
						constraint, _ := version.NewConstraint(">= 24.0.0")
						if constraint.Check(v) {
							geventVersionConstrained = true
						}
					}
				}
			}

			// if gevent doesn't have proper version constraint for Python 3.12, update it
			if !geventVersionConstrained {
				// 确保 gevent 版本 >= 24.0.0 以支持 Python 3.12
				if strings.Contains(trimmedLine, "==") {
					// 检查固定版本是否低于 24.0.0
					versionRe := regexp.MustCompile(`gevent==([0-9.]+)`)
					matches := versionRe.FindStringSubmatch(trimmedLine)
					if len(matches) >= 2 {
						v, err := version.NewVersion(matches[1])
						if err == nil {
							constraint, _ := version.NewConstraint("< 24.0.0")
							if constraint.Check(v) {
								// 升级到兼容版本
								lines[i] = "gevent>=24.2.0"
								log.Warn("gevent version < 24.0.0 detected, upgrading to >=24.2.0 for Python 3.12 compatibility")
								modified = true
							}
						}
					}
				} else if strings.Contains(trimmedLine, ">=") || strings.Contains(trimmedLine, ">") {
					// 检查版本约束是否足够高
					versionRe := regexp.MustCompile(`gevent[>]?=([0-9.]+)`)
					matches := versionRe.FindStringSubmatch(trimmedLine)
					if len(matches) >= 2 {
						v, err := version.NewVersion(matches[1])
						if err == nil {
							constraint, _ := version.NewConstraint("< 24.0.0")
							if constraint.Check(v) {
								// 更新版本约束
								lines[i] = "gevent>=24.2.0"
								log.Info("updating gevent version constraint to >=24.2.0 for Python 3.12 compatibility")
								modified = true
							}
						}
					}
				} else {
					// 没有版本约束，添加一个
					lines[i] = "gevent>=24.2.0"
					log.Info("adding gevent version constraint (>=24.2.0) for Python 3.12 compatibility")
					modified = true
				}
				geventVersionConstrained = true
			}
		}
	}

	// if numpy was found but not properly constrained, we've modified it
	if modified {
		newContent := strings.Join(lines, "\n")
		if err := os.WriteFile(requirementsPath, []byte(newContent), 0644); err != nil {
			return false, fmt.Errorf("failed to write patched requirements.txt: %s", err)
		}
		log.Info("patched requirements.txt to ensure numpy<2.0 and gevent>=24.0.0 compatibility for plugin %s", p.Config.Identity())
		return true, nil // needs rebuild to install correct version
	} else {
		if hasNumpy && numpyVersionConstrained {
			log.Info("numpy version constraint detected in requirements.txt, no patching needed")
		}
		if hasGevent && geventVersionConstrained {
			log.Info("gevent version constraint detected in requirements.txt, no patching needed")
		}
	}

	return false, nil // no rebuild needed
}

func (p *LocalPluginRuntime) getPluginSdkVersion(requirements string) (string, error) {
	// using regex to find the version of the plugin sdk
	// First try to match exact version or compatible version
	re := regexp.MustCompile(`(?:dify[_-]plugin)(?:~=|==)([0-9.a-z]+)`)
	matches := re.FindStringSubmatch(requirements)
	if len(matches) >= 2 {
		return matches[1], nil
	}

	// Try to match version ranges with multiple constraints
	// Extract all version constraints for dify-plugin
	// Try to match version ranges with multiple constraints
	// For example: dify-plugin>=0.1.0,<0.2.0
	reAllConstraints := regexp.MustCompile(`(?:dify[_-]plugin)([><]=?|==)([0-9.a-z]+)(?:,([><]=?|==)([0-9.a-z]+))?`)
	allMatches := reAllConstraints.FindAllStringSubmatch(requirements, -1)

	if len(allMatches) > 0 {
		// Always return the highest version among all constraints
		var highestVersion *version.Version
		var versionStr string

		for _, match := range allMatches {
			// Check for the second version constraint if it exists
			if len(match) >= 5 {
				currentVersionStr := match[4]
				currentVersion, err := version.NewVersion(currentVersionStr)
				if err != nil {
					continue
				}

				if highestVersion == nil || currentVersion.GreaterThan(highestVersion) {
					highestVersion = currentVersion
					versionStr = currentVersionStr
				}
			} else if len(match) >= 3 {
				currentVersionStr := match[2]
				currentVersion, err := version.NewVersion(currentVersionStr)
				if err != nil {
					continue
				}

				if highestVersion == nil || currentVersion.GreaterThan(highestVersion) {
					highestVersion = currentVersion
					versionStr = currentVersionStr
				}
			}
		}

		if versionStr != "" {
			return versionStr, nil
		}

		// If we couldn't parse any versions but have matches, return the first one
		if len(allMatches[0]) >= 3 {
			return allMatches[0][2], nil
		}
	}

	return "", fmt.Errorf("failed to find the version of the plugin sdk")
}
