package local_runtime

import (
	"github.com/langgenius/dify-plugin-daemon/internal/core/plugin_daemon/access_types"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/log"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/parser"
	"github.com/langgenius/dify-plugin-daemon/pkg/entities"
	"github.com/langgenius/dify-plugin-daemon/pkg/entities/plugin_entities"
)

func (r *LocalPluginRuntime) Listen(session_id string) *entities.Broadcast[plugin_entities.SessionMessage] {
	listener := entities.NewBroadcast[plugin_entities.SessionMessage]()
	
	// Capture stdioHolder in local variable to avoid TOCTOU race condition
	// This ensures we use the same instance throughout this function even if
	// r.stdioHolder is set to nil by another goroutine during execution
	holder := r.stdioHolder
	if holder == nil {
		log.Warn("attempt to listen on stopped plugin %s, session %s", r.Config.Identity(), session_id)
		// Close the listener immediately to signal the caller
		listener.Close()
		return listener
	}
	
	listener.OnClose(func() {
		// Use captured holder to avoid race condition
		holder.removeStdioHandlerListener(session_id)
	})
	
	holder.setupStdioEventListener(session_id, func(b []byte) {
		// unmarshal the session message
		data, err := parser.UnmarshalJsonBytes[plugin_entities.SessionMessage](b)
		if err != nil {
			log.Error("unmarshal json failed: %s, failed to parse session message", err.Error())
			return
		}

		listener.Send(data)
	})
	return listener
}

func (r *LocalPluginRuntime) Write(session_id string, action access_types.PluginAccessAction, data []byte) {
	// Capture stdioHolder in local variable to avoid TOCTOU race condition
	holder := r.stdioHolder
	if holder == nil {
		log.Warn("attempt to write to stopped plugin %s, session %s", r.Config.Identity(), session_id)
		return
	}
	
	holder.write(append(data, '\n'))
}
