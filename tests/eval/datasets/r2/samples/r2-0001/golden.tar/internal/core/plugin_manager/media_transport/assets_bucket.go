package media_transport

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path"
	"path/filepath"
	"sync"
	"sync/atomic"
	"time"

	lru "github.com/hashicorp/golang-lru/v2"
	"github.com/langgenius/dify-cloud-kit/oss"
	"github.com/langgenius/dify-plugin-daemon/internal/utils/log"
)

type MediaBucket struct {
	oss         oss.OSS
	cache       *lru.Cache[string, []byte]
	mediaPath   string
	maxDiskSize int64
	diskUsage   atomic.Int64
	usageLock   sync.Mutex
}

func NewAssetsBucket(oss oss.OSS, media_path string, cache_size uint16) *MediaBucket {
	// lru.New only raises error when cache_size is a negative number, which is impossible
	cache, _ := lru.New[string, []byte](int(cache_size))

	bucket := &MediaBucket{
		oss:         oss,
		cache:       cache,
		mediaPath:   media_path,
		maxDiskSize: 0, // Will be set by manager if configured
	}

	return bucket
}

// SetMaxDiskSize sets the maximum disk size for the media bucket
func (m *MediaBucket) SetMaxDiskSize(maxSize int64) {
	m.maxDiskSize = maxSize
	// Calculate current disk usage
	go m.calculateDiskUsage()
}

// calculateDiskUsage calculates the current disk usage
func (m *MediaBucket) calculateDiskUsage() {
	m.usageLock.Lock()
	defer m.usageLock.Unlock()

	var totalSize int64
	paths, err := m.oss.List(m.mediaPath)
	if err != nil {
		log.Error("failed to list media files for usage calculation: %s", err)
		return
	}

	for _, p := range paths {
		if !p.IsDir {
			// Get file state to retrieve size
			state, err := m.oss.State(p.Path)
			if err == nil {
				totalSize += state.Size
			}
		}
	}

	m.diskUsage.Store(totalSize)
	log.Info("media cache disk usage: %d bytes (%.2f GB)", totalSize, float64(totalSize)/(1024*1024*1024))
}

// Upload uploads a file to the media manager and returns an identifier
func (m *MediaBucket) Upload(name string, file []byte) (string, error) {
	fileSize := int64(len(file))

	// Check if we need to enforce limits
	if m.maxDiskSize > 0 {
		// Try to make space if needed
		if err := m.enforceLimit(fileSize); err != nil {
			return "", err
		}
	}

	// calculate checksum
	checksum := sha256.Sum256(append(file, []byte(name)...))

	id := hex.EncodeToString(checksum[:])

	// get file extension
	ext := filepath.Ext(name)

	filename := id + ext

	// store locally
	filePath := path.Join(m.mediaPath, filename)
	err := m.oss.Save(filePath, file)
	if err != nil {
		return "", err
	}

	// Update disk usage
	if m.maxDiskSize > 0 {
		m.diskUsage.Add(fileSize)
	}

	return filename, nil
}

// enforceLimit ensures disk usage stays within limits by evicting old files if necessary
func (m *MediaBucket) enforceLimit(newFileSize int64) error {
	currentUsage := m.diskUsage.Load()

	// If adding this file would exceed the limit, evict old files
	if currentUsage+newFileSize > m.maxDiskSize {
		m.usageLock.Lock()
		defer m.usageLock.Unlock()

		log.Info("media cache approaching limit, attempting to evict old files")

		// Get all files with their modification times
		paths, err := m.oss.List(m.mediaPath)
		if err != nil {
			return err
		}

		// Sort by modification time (oldest first)
		type fileInfo struct {
			path    string
			size    int64
			modTime time.Time
		}

		files := make([]fileInfo, 0, len(paths))
		for _, p := range paths {
			if !p.IsDir {
				// Get file info to determine modification time and size
				fullPath := path.Join(m.mediaPath, filepath.Base(p.Path))
				stat, err := os.Stat(fullPath)
				if err == nil {
					// Get size from OSS state
					state, stateErr := m.oss.State(p.Path)
					fileSize := int64(0)
					if stateErr == nil {
						fileSize = state.Size
					} else {
						// Fallback to os.Stat size
						fileSize = stat.Size()
					}
					
					files = append(files, fileInfo{
						path:    fullPath,
						size:    fileSize,
						modTime: stat.ModTime(),
					})
				}
			}
		}

		// Sort by modification time
		for i := 0; i < len(files)-1; i++ {
			for j := i + 1; j < len(files); j++ {
				if files[i].modTime.After(files[j].modTime) {
					files[i], files[j] = files[j], files[i]
				}
			}
		}

		// Evict oldest files until we have enough space
		freedSpace := int64(0)
		neededSpace := (currentUsage + newFileSize) - m.maxDiskSize

		for _, file := range files {
			if freedSpace >= neededSpace {
				break
			}

			log.Info("evicting old media file: %s (size: %d bytes)", filepath.Base(file.path), file.size)
			if err := m.oss.Delete(file.path); err != nil {
				log.Error("failed to delete file %s: %s", file.path, err)
				continue
			}

			// Remove from cache if present
			m.cache.Remove(filepath.Base(file.path))

			freedSpace += file.size
			m.diskUsage.Add(-file.size)
		}

		if freedSpace >= neededSpace {
			log.Info("successfully freed %d bytes by evicting %d files", freedSpace, len(files))
		} else {
			log.Warn("could not free enough space, freed %d bytes but needed %d bytes", freedSpace, neededSpace)
		}
	}

	return nil
}

func (m *MediaBucket) Get(id string) ([]byte, error) {
	// check if id is in cache
	data, ok := m.cache.Get(id)
	if ok {
		return data, nil
	}

	// check if id is in storage
	filePath := path.Join(m.mediaPath, id)
	file, err := m.oss.Load(filePath)
	if err != nil {
		return nil, err
	}

	// store in cache
	m.cache.Add(id, file)

	return file, nil
}

func (m *MediaBucket) Delete(id string) error {
	// delete from cache
	m.cache.Remove(id)

	// Get file size before deleting
	filePath := path.Join(m.mediaPath, id)
	if m.maxDiskSize > 0 {
		if stat, err := os.Stat(filePath); err == nil {
			m.diskUsage.Add(-stat.Size())
		}
	}

	// delete from storage
	return m.oss.Delete(filePath)
}
