package controllers

import (
	"runtime"

	"github.com/gin-gonic/gin"
)

// TriggerGC manually triggers garbage collection (use with caution)
func TriggerGC(c *gin.Context) {
	runtime.GC()
	c.JSON(200, gin.H{
		"status":  "ok",
		"message": "garbage collection triggered",
	})
}

