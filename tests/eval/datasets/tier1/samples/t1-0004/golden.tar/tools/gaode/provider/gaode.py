import urllib.parse
import requests
from dify_plugin.errors.tool import ToolProviderCredentialValidationError
from dify_plugin import ToolProvider
import os

class GaodeProvider(ToolProvider):
    def _validate_credentials(self) -> None:
        try:
            try:
                GAODE_API_KEY = os.environ.get("GAODE_API_KEY")
                if not GAODE_API_KEY:
                    raise ToolProviderCredentialValidationError("GAODE_API_KEY is not set")
                response = requests.get(
                    url="https://restapi.amap.com/v3/geocode/geo?address={address}&key={apikey}".format(
                        address=urllib.parse.quote("广东省广州市天河区广州塔"), apikey=GAODE_API_KEY
                    )
                )
                if response.status_code == 200 and response.json().get("info") == "OK":
                    pass
                else:
                    raise ToolProviderCredentialValidationError(response.json().get("info"))
            except Exception as e:
                raise ToolProviderCredentialValidationError("Gaode API Key is invalid. {}".format(e))
        except Exception as e:
            raise ToolProviderCredentialValidationError(str(e))
