import json
import os
from typing import Any, Generator
import requests
from dify_plugin.entities.tool import ToolInvokeMessage
from dify_plugin import Tool


class GaodeRoutePlan(Tool):

    def _invoke(
        self, tool_parameters: dict[str, Any]
    ) -> Generator[ToolInvokeMessage, None, None]:
        """
        invoke tools
        """
        GAODE_API_KEY = os.environ.get("GAODE_API_KEY")
        if not GAODE_API_KEY:
            raise Exception("GAODE_API_KEY is not set")

        try:
            starting_city = tool_parameters.get("starting_city")
            destination_city = tool_parameters.get("destination_city")

            start_city_location = self.get_location(starting_city, GAODE_API_KEY)
            destination_city_location = self.get_location(destination_city, GAODE_API_KEY)
            route_plan = self.get_route_plan(start_city_location, destination_city_location, GAODE_API_KEY)
            yield self.create_text_message(json.dumps(route_plan, ensure_ascii=False))
        except Exception as e:
            raise Exception(f"Failed to get route plan for {e}")


    @staticmethod
    def get_location(city: str, api_key: str):
        location_url = f"https://restapi.amap.com/v3/geocode/geo?output=json&key={api_key}&address={city}"
        response = requests.get(location_url)
        if response.status_code != 200:
            raise Exception(f"Failed to get location for {city}")

        response_body = response.json()
        if response_body["status"] != "1":
            raise Exception(f"Failed to get location {response_body['info']}")

        location = response_body["geocodes"][0]["location"]
        return location

    @staticmethod
    def get_route_plan(start_location, destination_location, api_key: str):
        route_plan_url = f"https://restapi.amap.com/v5/direction/driving?origin={start_location}&destination={destination_location}&key={api_key}&show_fields=cost"
        response = requests.get(route_plan_url)
        if response.status_code != 200:
            raise Exception(f"Failed to get route plan for {start_location} to {destination_location}")
        response_json = response.json()
        if response_json["infocode"] == "10000":
            return response_json["route"]
        else:
            raise Exception(f"Failed to get route plan for {response_json['info']}")