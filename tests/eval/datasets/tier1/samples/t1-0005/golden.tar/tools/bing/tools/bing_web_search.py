import mimetypes
import re
import subprocess
import time
from typing import Any, Union, Optional,Generator
from urllib.parse import quote, urlparse

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from dify_plugin import Tool
from dify_plugin.entities.tool import ToolInvokeMessage
from config import BING_API_KEY


def deduplicate_results(results: list, key: str) -> list:
    seen = set()
    unique = []
    for item in results:
        value = item.get(key)
        if value and value not in seen:
            seen.add(value)
            unique.append(item)
    return unique


class BingWebSearchTool(Tool):
    url: str = "https://api.bing.microsoft.com/v7.0/search"

    def _create_session(self) -> requests.Session:
        """
        Create a requests session with retry strategy and SSL configuration
        """
        session = requests.Session()
        
        # Configure retry strategy
        retry_strategy = Retry(
            total=3,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "POST"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session

    def _invoke_bing(
        self,
        subscription_key: str,
        query: str,
        limit: int,
        result_type: str,
        market: str,
        lang: str,
        filters: list[str],
        freshness: Optional[str] = None,
    ) -> Generator[ToolInvokeMessage, None, None]:
        """
        invoke bing search

        当 query 包含多个搜索条件（以分号分隔）时，将采用 for 循环方式单独请求，再将结果合并
        """
        if not query:
            yield self.create_text_message("Please input query")
            return

        if ";" in query:
            query_list = [q.strip() for q in query.split(";") if q.strip()]
        else:
            query_list = [query]

        all_webPages = []
        all_relatedSearches = []
        all_entities = []
        all_news = []
        all_images = []
        all_videos = []
        all_computation = []

        market_code = f"{lang}-{market}"
        accept_language = f"{lang},{market_code};q=0.9"
        headers = {"Ocp-Apim-Subscription-Key": subscription_key, "Accept-Language": accept_language}

        # Create session with retry strategy
        session = self._create_session()

        for q in query_list:
            q_encoded = quote(q)
            if freshness:
                server_url = f"{self.url}?q={q_encoded}&mkt={market_code}&count={limit}&freshness={freshness}&responseFilter={','.join(filters)}"
            else:
                server_url = (
                    f"{self.url}?q={q_encoded}&mkt={market_code}&count={limit}&responseFilter={','.join(filters)}"
                )

            max_retries = 3
            for attempt in range(max_retries):
                try:
                    response = session.get(
                        server_url, 
                        headers=headers, 
                        timeout=(10, 30),  # (connect_timeout, read_timeout)
                        verify=True  # Verify SSL certificates
                    )
                    if response.status_code != 200:
                        # Log the error for debugging
                        print(f"API request failed with status {response.status_code}: {response.text}")
                        if attempt == max_retries - 1:
                            break
                        time.sleep(1)  # Wait before retry
                        continue
                    break  # Success, exit retry loop
                except requests.exceptions.SSLError as e:
                    print(f"SSL error on attempt {attempt + 1}: {str(e)}")
                    if attempt == max_retries - 1:
                        print(f"SSL error after {max_retries} attempts, skipping query: {q}")
                        break
                    time.sleep(2)  # Wait longer for SSL issues
                    continue
                except requests.exceptions.ConnectionError as e:
                    print(f"Connection error on attempt {attempt + 1}: {str(e)}")
                    if attempt == max_retries - 1:
                        print(f"Connection error after {max_retries} attempts, skipping query: {q}")
                        break
                    time.sleep(2)  # Wait before retry
                    continue
                except Exception as e:
                    print(f"Exception during API request on attempt {attempt + 1}: {str(e)}")
                    if attempt == max_retries - 1:
                        print(f"Exception after {max_retries} attempts, skipping query: {q}")
                        break
                    time.sleep(1)  # Wait before retry
                    continue
            else:
                # If we get here, all retries failed
                continue

            # Check if response is defined and successful
            if 'response' not in locals() or response.status_code != 200:
                continue

            try:
                data = response.json()
                print(f"API response keys: {list(data.keys())}")
                
                if "webPages" in data:
                    webpages_count = len(data["webPages"]["value"][:limit])
                    print(f"Adding {webpages_count} webpages")
                    all_webPages.extend(data["webPages"]["value"][:limit])
                if "relatedSearches" in data:
                    related_count = len(data["relatedSearches"]["value"])
                    print(f"Adding {related_count} related searches")
                    all_relatedSearches.extend(data["relatedSearches"]["value"])
                if "entities" in data:
                    entities_count = len(data["entities"]["value"])
                    print(f"Adding {entities_count} entities")
                    all_entities.extend(data["entities"]["value"])
                if "news" in data:
                    news_count = len(data["news"]["value"])
                    print(f"Adding {news_count} news items")
                    all_news.extend(data["news"]["value"])
                if "images" in data:
                    images_count = len(data["images"]["value"])
                    print(f"Adding {images_count} images")
                    all_images.extend(data["images"]["value"])
                if "videos" in data:
                    videos_count = len(data["videos"]["value"])
                    print(f"Adding {videos_count} videos")
                    all_videos.extend(data["videos"]["value"])
                if "computation" in data:
                    print(f"Adding computation result")
                    all_computation.append(data["computation"]["value"])
            except ValueError as e:
                print(f"Failed to parse JSON response: {str(e)}")
                continue

        all_webPages = deduplicate_results(all_webPages, "url")
        all_entities = deduplicate_results(all_entities, "url")
        all_news = deduplicate_results(all_news, "url")
        all_images = deduplicate_results(all_images, "contentUrl")
        all_videos = deduplicate_results(all_videos, "contentUrl")
        all_relatedSearches = deduplicate_results(all_relatedSearches, "webSearchUrl")

        if not (
            all_webPages
            or all_relatedSearches
            or all_entities
            or all_news
            or all_images
            or all_videos
            or all_computation
        ):
            yield self.create_text_message("No results found")
            return

        if result_type == "link":
            results = []
            if all_webPages:
                for result in all_webPages:
                    url = result.get("url")
                    results.append(
                        self.create_text_message(text=f"[{result.get('name', '')}]({': ' + url if url else ''})")
                    )
            if all_entities:
                for entity in all_entities:
                    url = entity.get("url")
                    results.append(
                        self.create_text_message(text=f"{entity.get('name', '')})[{': ' + url if url else ''})")
                    )
            if all_videos:
                for entity in all_videos:
                    url = entity.get("contentUrl")
                    results.append(
                        self.create_text_message(text=f"{entity.get('name', '')})[{': ' + url if url else ''})")
                    )
            if all_news:
                for news_item in all_news:
                    url = news_item.get("url")
                    results.append(
                        self.create_text_message(text=f"[{news_item.get('name', '')}]({': ' + url if url else ''})")
                    )
            if all_relatedSearches:
                for related in all_relatedSearches:
                    url = related.get("webSearchUrl")
                    results.append(
                        self.create_text_message(
                            text=f"[{related.get('displayText', '')}]({': ' + url if url else ''})"
                        )
                    )
            yield from results
            return
        elif result_type == "json":
            result = {}
            if all_webPages:
                result["webPages"] = [
                    {
                        "title": item.get("name", ""),
                        "snippet": item.get("snippet", ""),
                        "url": item.get("url", ""),
                        "siteIcon": f"{urlparse(item.get('url', '')).scheme}://{urlparse(item.get('url', '')).netloc}/favicon.ico"
                        if item.get("url")
                        else "",
                        "publishedAt": item.get("datePublished", ""),
                    }
                    for item in all_webPages
                    if item.get("url")
                ]
            if all_videos:
                result["videos"] = [
                    {
                        "title": item.get("name", ""),
                        "snippet": item.get("description", ""),
                        "url": item.get("contentUrl", ""),
                        "videoUrl": re.search(r'src=".*?>(.*?)</url>', item.get("embedHtml", "")),
                        "siteIcon": f"{urlparse(item.get('contentUrl', '')).scheme}://{urlparse(item.get('contentUrl', '')).netloc}/favicon.ico"
                        if item.get("contentUrl")
                        else "",
                        "publishedAt": item.get("datePublished", ""),
                    }
                    for item in all_videos
                    if item.get("embedHtml")
                ]
            if all_images:
                result["images"] = [
                    {
                        "title": item.get("name", ""),
                        "snippet": item.get("contentUrl", ""),
                        "url": item.get("hostPageUrl", ""),
                        "siteIcon": f"{urlparse(item.get('hostPageUrl', '')).scheme}://{urlparse(item.get('hostPageUrl', '')).netloc}/favicon.ico"
                        if item.get("hostPageUrl")
                        else "",
                        "publishedAt": item.get("datePublished", ""),
                    }
                    for item in all_images
                    if item.get("hostPageUrl")
                ]
            if all_computation:
                comp = all_computation[0]
                if comp and "expression" in comp and "value" in comp:
                    result["computation"] = {"expression": comp["expression"], "value": comp["value"]}
            if all_entities:
                result["entities"] = [
                    {
                        "name": item.get("name", ""),
                        "url": item.get("url", ""),
                        "description": item.get("description", ""),
                    }
                    for item in all_entities
                ]
            if all_news:
                result["news"] = [{"name": item.get("name", ""), "url": item.get("url", "")} for item in all_news]
            if all_relatedSearches:
                result["related searches"] = [
                    {"displayText": item.get("displayText", ""), "url": item.get("webSearchUrl", "")}
                    for item in all_relatedSearches
                ]
            yield self.create_json_message(result)
            return
        else:
            text = ""
            if all_webPages:
                text += "\nSearch:\n"
                for result in all_webPages:
                    url = result.get("url")
                    text += (
                        f"snippet: {result.get('snippet', '')}; from: {url}\n"
                        if url
                        else f"description: {result.get('description', '')}\n"
                    )
            if all_videos:
                text += "\nVideos:\n"
                for result in all_videos:
                    url = result.get("contentUrl")
                    text += (
                        f"snippet: {result.get('description', '')}; from: {url}\n"
                        f"embedHtml: {result.get('embedHtml', '')}\n"
                    )
            if all_computation:
                comp = all_computation[0]
                if comp:
                    text += "\nComputation:\n"
                    text += f"{comp.get('expression', '')} = {comp.get('value', '')}\n"
            if all_entities:
                text += "\nEntities:\n"
                for entity in all_entities:
                    url = entity.get("url")
                    text += (
                        f"description: {entity.get('name', '')}; from: {url}\n"
                        if url
                        else f"description: {entity.get('name', '')}\n"
                    )
            if all_news:
                text += "\nNews:\n"
                for news_item in all_news:
                    url = news_item.get("url")
                    text += (
                        f"description: {news_item.get('description', '')}; from: {url}\n"
                        if url
                        else f"description: {news_item.get('description', '')}\n"
                    )
            if all_images:
                text += "\nImages:\n"
                for images_item in all_images:
                    url = images_item.get("contentUrl")
                    if self._is_image_url(url):
                        text += f"![{images_item.get('name', '')}]({url})\n"
                    else:
                        text += (
                            f"description: {images_item.get('name', '')}; from: {url}\n"
                            if url
                            else f"description: {images_item.get('name', '')}\n"
                        )
            if all_videos:
                text += "\nVideos:\n"
                for videos_item in all_videos:
                    url = videos_item.get("contentUrl")
                    if self._is_video_url(url):
                        text += f"![{videos_item.get('description', '')}]({url})\n"
                    else:
                        text += (
                            f"description: {videos_item.get('description', '')}; from: {url}\n"
                            if url
                            else f"description: {videos_item.get('name', '')}\n"
                        )
            if all_relatedSearches:
                text += "\n\nRelated Searches:\n"
                for related in all_relatedSearches:
                    url = related.get("webSearchUrl")
                    text += (
                        f"description: {related.get('displayText', '')}; from: {url}\n"
                        if url
                        else f"description: {related.get('displayText', '')}\n"
                    )
            yield self.create_text_message(text=self.summary(content=text))

    def validate_credentials(self, credentials: dict[str, Any], tool_parameters: dict[str, Any]) -> None:
        query = tool_parameters.get("query")
        if not query:
            raise Exception("query is required")

        limit = min(tool_parameters.get("limit", 10), 50)
        result_type = tool_parameters.get("result_type", "text") or "text"

        market = tool_parameters.get("market", "US")
        lang = tool_parameters.get("language", "en")
        freshness = tool_parameters.get("freshness")
        filters = []

        if credentials.get("allow_entities", False):
            filters.append("Entities")
        if credentials.get("allow_computation", False):
            filters.append("Computation")
        if credentials.get("allow_news", False):
            filters.append("News")
        if credentials.get("allow_related_searches", False):
            filters.append("RelatedSearches")
        if credentials.get("allow_web_pages", False):
            filters.append("WebPages")
        if tool_parameters.get("allow_images_searches", False):
            filters.append("Images")
        if tool_parameters.get("allow_videos_searches", False):
            filters.append("Videos")
        if tool_parameters.get("enable_related_search", False):
            filters.append("RelatedSearches")

        if not filters:
            raise Exception("At least one filter is required")

        # Test the API call by consuming the generator
        try:
            results = list(self._invoke_bing(
                subscription_key=BING_API_KEY,
                query=query,
                limit=limit,
                result_type=result_type,
                market=market,
                freshness=freshness,
                lang=lang,
                filters=filters,
            ))
            print(f"-------validation results count: {len(results)}")
        except Exception as e:
            raise Exception(f"API validation failed: {str(e)}")

    def _invoke(
        self, tool_parameters: dict[str, Any]
    ) -> Generator[ToolInvokeMessage, None, None]:
        """
        invoke tools
        """

        query = tool_parameters.get("query")
        if not query:
            raise Exception("query is required")

        limit = min(tool_parameters.get("limit", 10), 50)
        result_type = tool_parameters.get("result_type", "text") or "text"

        market = tool_parameters.get("market", "US")
        lang = tool_parameters.get("language", "en")

        # Use list comprehension instead of multiple append operations
        filter_options = [
            ("enable_related_search", "RelatedSearches"),
            ("enable_webpages", "WebPages"),
            ("enable_images", "Images"),
            ("enable_videos", "Videos"),
            ("enable_computation", "Computation"),
            ("enable_entities", "Entities"),
            ("enable_news", "News"),
        ]

        filter = [value for key, value in filter_options if tool_parameters.get(key, False)]

        if not filter:
            raise Exception("At least one filter is required")

        print(f"-------invoke params: query={query}, limit={limit}, result_type={result_type}, market={market}, lang={lang}, filters={filter}")
        
        results = list(self._invoke_bing(
            subscription_key=BING_API_KEY,
            query=query,
            limit=limit,
            result_type=result_type,
            market=market,
            lang=lang,
            filters=filter,
            freshness=tool_parameters.get("freshness"),
        ))
        
        print(f"-------invoke results count: {len(results)}")
        
        # Yield all results from the generator
        yield from results

    def _is_image_url(self, url):
        """
        Determine if the URL points to an image by checking file extension and Content-Type.
        """
        try:
            parsed_url = urlparse(url)
            extension = parsed_url.path.split(".")[-1].lower()
            valid_image_extensions = {"jpg", "jpeg", "png", "gif", "bmp", "webp"}
            if extension in valid_image_extensions:
                return True

            # Create session with retry strategy for better connection handling
            session = self._create_session()
            response = session.head(url, allow_redirects=True, timeout=5)
            if response.status_code == 200:
                content_type = response.headers.get("Content-Type", "").lower()
                if "image" in content_type:
                    return True
        except Exception:
            return False

    def _is_video_url(self, url):
        """
        Determine if the URL points to a video by checking file extension, mimetype and using ffprobe.
        """
        if not url:
            return False
            
        try:
            parsed_url = urlparse(url)
            extension = f".{parsed_url.path.split('.')[-1].lower()}"
            valid_video_extensions = {".mp4", ".avi", ".mov", ".mkv", ".flv", ".wmv"}
            if extension in valid_video_extensions:
                return True

            mime_type, _ = mimetypes.guess_type(url)
            if mime_type and mime_type.startswith("video/"):
                return True

            result = subprocess.run(
                [
                    "ffprobe",
                    "-v",
                    "error",
                    "-select_streams",
                    "v:0",
                    "-show_entries",
                    "stream=codec_type",
                    "-of",
                    "csv=p=0",
                    url,
                ],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0 and "video" in result.stdout.lower():
                return True
        except Exception:
            pass
        
        return False
    
    def summary(self, content: str) -> str:
        """
        Summarize content using the session's summary capability
        """
        try:
            # Use plugin's summary capability if available
            result = self.session.model.summary.invoke(text=content, instruction="")
            # Ensure we return a string
            if isinstance(result, tuple):
                return result[0] if result else content
            return str(result) if result else content
        except Exception:
            # Fallback to original content if summary fails
            return content