"""
Bing Search Tool Configuration
"""

import os

BING_API_KEY = os.environ.get("DIFY_ADMIN_TOKEN", "") 