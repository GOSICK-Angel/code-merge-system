import concurrent.futures
import os
import requests
from typing import Any, Optional
from dify_plugin import TTSModel
from dify_plugin.entities.model import AIModelEntity, FetchFrom, I18nObject, ModelType
from dify_plugin.errors.model import (
    CredentialsValidateFailedError,
    InvokeAuthorizationError,
    InvokeBadRequestError,
    InvokeConnectionError,
    InvokeError,
    InvokeRateLimitError,
    InvokeServerUnavailableError,
)
from xinference_client.client.restful.restful_client import RESTfulAudioModelHandle

from models.xinference_helper import XinferenceHelper


class XinferenceText2SpeechModel(TTSModel):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        current_file_path = os.path.abspath(__file__)
        current_dir = os.path.dirname(current_file_path)
        self.model_voices = {
            "__default": {
                "all": [
                    {"name": "Default", "value": "default"},
                ]
            },
            "ChatTTS": {
                "all": [
                    {"name": "Alloy", "value": "alloy"},
                    {"name": "Echo", "value": "echo"},
                    {"name": "Fable", "value": "fable"},
                    {"name": "Onyx", "value": "onyx"},
                    {"name": "Nova", "value": "nova"},
                    {"name": "Shimmer", "value": "shimmer"},
                ]
            },
            "Kokoro-82M": {
                "all": [
                    {"name": "Alloy", "value": "af_alloy"},
                    {"name": "Aoede", "value": "af_aoede"},
                    {"name": "Bella", "value": "af_bella"},
                    {"name": "Jessica", "value": "af_jessica"},
                    {"name": "Kore", "value": "af_kore"},
                    {"name": "Nicole", "value": "af_nicole"},
                    {"name": "Nova", "value": "af_nova"},
                    {"name": "River", "value": "af_river"},
                    {"name": "Sarah", "value": "af_sarah"},
                    {"name": "Sky", "value": "af_sky"},
                    {"name": "Adam", "value": "am_adam"},
                    {"name": "Echo", "value": "am_echo"},
                    {"name": "Eric", "value": "am_eric"},
                    {"name": "Fenrir", "value": "am_fenrir"},
                    {"name": "Liam", "value": "am_liam"},
                    {"name": "Michael", "value": "am_michael"},
                    {"name": "Onyx", "value": "am_onyx"},
                    {"name": "Puck", "value": "am_puck"},
                    {"name": "Alice", "value": "bf_alice"},
                    {"name": "Emma", "value": "bf_emma"},
                    {"name": "Isabella", "value": "bf_isabella"},
                    {"name": "Lily", "value": "bf_lily"},
                    {"name": "Daniel", "value": "bm_daniel"},
                    {"name": "Fable", "value": "bm_fable"},
                    {"name": "George", "value": "bm_george"},
                    {"name": "Lewis", "value": "bm_lewis"},
                ]
            },
            "CosyVoice": {
                "zh-Hans": [
                    {"name": "中文男", "value": "中文男"},
                    {"name": "中文女", "value": "中文女"},
                    {"name": "粤语女", "value": "粤语女"},
                ],
                "zh-Hant": [
                    {"name": "中文男", "value": "中文男"},
                    {"name": "中文女", "value": "中文女"},
                    {"name": "粤语女", "value": "粤语女"},
                ],
                "en-US": [
                    {"name": "英文男", "value": "英文男"},
                    {"name": "英文女", "value": "英文女"},
                ],
                "ja-JP": [
                    {"name": "日语男", "value": "日语男"},
                ],
                "ko-KR": [
                    {"name": "韩语女", "value": "韩语女"},
                ],
            },
            "MegaTTS3": {
                "zh-Hans": [
                    {
                        "name": "Default", "value": "default",
                        "prompt_speech_path": os.path.normpath(os.path.join(current_dir, "../..", "_assets/MegaTTS3", "Chinese_prompt.wav")),
                        "prompt_latent_path": os.path.normpath(os.path.join(current_dir, "../..", "_assets/MegaTTS3", "Chinese_prompt.npy"))
                    },
                    {
                        "name": "新闻", "value": "新闻",
                        "prompt_speech_path": os.path.normpath(os.path.join(current_dir, "../..", "_assets/MegaTTS3", "新闻.wav")),
                        "prompt_latent_path": os.path.normpath(os.path.join(current_dir, "../..", "_assets/MegaTTS3", "新闻.npy"))
                    },
                    {
                        "name": "范闲", "value": "范闲",
                        "prompt_speech_path": os.path.normpath(os.path.join(current_dir, "../..", "_assets/MegaTTS3", "范闲.wav")),
                        "prompt_latent_path": os.path.normpath(os.path.join(current_dir, "../..", "_assets/MegaTTS3", "范闲.npy"))
                    },
                ],
                "en-US": [
                    {
                        "name": "Default", "value": "default",
                        "prompt_speech_path": os.path.normpath(os.path.join(current_dir, "..", "_assets/MegaTTS3", "English_prompt.wav")),
                        "prompt_latent_path": os.path.normpath(os.path.join(current_dir, "..", "_assets/MegaTTS3", "English_prompt.npy"))
                    },
                    {
                        "name": "bbc_news", "value": "bbc_news",
                        "prompt_speech_path": os.path.normpath(os.path.join(current_dir, "..", "_assets/MegaTTS3", "bbc_news.wav")),
                        "prompt_latent_path": os.path.normpath(os.path.join(current_dir, "..", "_assets/MegaTTS3", "bbc_news.npy"))
                    },
                ]
            },
        }

    def validate_credentials(self, model: str, credentials: dict) -> None:
        """
        Validate model credentials

        :param model: model name
        :param credentials: model credentials
        :return:
        """
        try:
            if "model_uid" in credentials:
                model_uid = credentials["model_uid"]
            else:
                model_uids = [d.get("model_uid") for d in credentials["models"] if d.get("model_name") == model]
                if len(model_uids) > 0:
                    model_uid = model_uids[0]
                else:
                    raise InvokeBadRequestError(f"please check model {model} uid config")
            # if not validate_model_uid(credentials):
            #     raise CredentialsValidateFailedError(
            #         "model_uid should not contain /, ?, or #"
            #     )
            credentials["server_url"] = credentials["server_url"].removesuffix("/")
            extra_param = XinferenceHelper.get_xinference_extra_parameter(
                server_url=credentials["server_url"],
                model_uid=model_uid,
                api_key=credentials.get("api_key"),
            )
            if "text-to-audio" not in extra_param.model_ability:
                raise InvokeBadRequestError(
                    "please check model type, the model you want to invoke is not a text-to-audio model"
                )
            if (
                extra_param.model_family
                and extra_param.model_family in self.model_voices
            ):
                credentials["audio_model_name"] = extra_param.model_family
            else:
                credentials["audio_model_name"] = "__default"
            self._tts_invoke_streaming(
                model=model,
                credentials=credentials,
                content_text="Hello Dify!",
                voice=self._get_model_default_voice(model, credentials),
            )
        except Exception as ex:
            raise CredentialsValidateFailedError(str(ex))

    def _invoke(
        self,
        model: str,
        tenant_id: str,
        credentials: dict,
        content_text: str,
        voice: str,
        user: Optional[str] = None,
    ):
        """
        _invoke text2speech model

        :param model: model name
        :param tenant_id: user tenant id
        :param credentials: model credentials
        :param voice: model timbre
        :param content_text: text content to be translated
        :param user: unique user id
        :return: text translated to audio file
        """
        return self._tts_invoke_streaming(model, credentials, content_text, voice)

    def get_customizable_model_schema(
        self, model: str, credentials: dict
    ) -> Optional[AIModelEntity]:
        """
        used to define customizable model schema
        """
        entity = AIModelEntity(
            model=model,
            label=I18nObject(en_US=model),
            fetch_from=FetchFrom.CUSTOMIZABLE_MODEL,
            model_type=ModelType.TTS,
            model_properties={},
            parameter_rules=[],
        )
        return entity

    @property
    def _invoke_error_mapping(self) -> dict[type[InvokeError], list[type[Exception]]]:
        """
        Map model invoke error to unified error
        The key is the error type thrown to the caller
        The value is the error type thrown by the model,
        which needs to be converted into a unified error type for the caller.

        :return: Invoke error mapping
        """
        return {
            InvokeConnectionError: [InvokeConnectionError],
            InvokeServerUnavailableError: [InvokeServerUnavailableError],
            InvokeRateLimitError: [InvokeRateLimitError],
            InvokeAuthorizationError: [InvokeAuthorizationError],
            InvokeBadRequestError: [InvokeBadRequestError, KeyError, ValueError],
        }

    def get_tts_model_voices(
        self, model: str, credentials: dict, language: Optional[str] = None
    ) -> list:
        audio_model_name = credentials.get("audio_model_name", "__default")
        for key, voices in self.model_voices.items():
            if key in audio_model_name:
                if language and language in voices:
                    return voices[language]
                elif "all" in voices:
                    return voices["all"]
                else:
                    all_voices = []
                    for lang, lang_voices in voices.items():
                        all_voices.extend(lang_voices)
                    return all_voices
        return self.model_voices["__default"]["all"]

    def _get_model_default_voice(self, model: str, credentials: dict) -> Any:
        return ""

    def _get_model_word_limit(self, model: str, credentials: dict) -> int:
        return 3500

    def _get_model_audio_type(self, model: str, credentials: dict) -> str:
        return "mp3"

    def _get_model_workers_limit(self, model: str, credentials: dict) -> int:
        return 5

    def _get_tts_model_prompt_data(self, model: str, credentials: dict, path_key: str, voice: str) -> Optional[bytes]:
        """
        Get prompt data (speech or latent) for voice cloning models
        """
        audio_model_name = model or credentials.get("audio_model_name", "__default")

        for key, voices in self.model_voices.items():
            if key in audio_model_name:
                # Search for the specific voice in all language collections
                for lang, voice_list in voices.items():
                    for voice_item in voice_list:
                        # Match by voice value
                        if voice_item.get("value") == voice and path_key in voice_item:
                            try:
                                file_path = voice_item[path_key]
                                if not os.path.exists(file_path):
                                    continue

                                # Read file as binary data
                                with open(file_path, 'rb') as file:
                                    return file.read()
                            except Exception as e:
                                # Log error but continue searching
                                raise f"Error reading prompt file for voice {voice}: {str(e)}"

                # If specific voice not found, try default voice
                for lang, voice_list in voices.items():
                    for voice_item in voice_list:
                        if voice_item.get("value") == "default" and path_key in voice_item:
                            try:
                                file_path = voice_item[path_key]
                                if not os.path.exists(file_path):
                                    continue

                                with open(file_path, 'rb') as file:
                                    return file.read()
                            except Exception as e:
                                raise f"Error reading default prompt file: {str(e)}"

                # No matching prompt found
                return None

        return None

    def _tts_invoke_streaming(
        self, model: str, credentials: dict, content_text: str, voice: str
    ) -> Any:
        """
        _tts_invoke_streaming text2speech model

        :param model: model name
        :param credentials: model credentials
        :param content_text: text content to be translated
        :param voice: model timbre
        :return: text translated to audio file
        """
        credentials["server_url"] = credentials["server_url"].removesuffix("/")
        stream = not any(x in str(model) for x in ["Kokoro-82M", "MegaTTS3"])

        if "model_uid" in credentials:
            model_uid = credentials["model_uid"]
        else:
            model_uids = [d.get("model_uid") for d in credentials["models"] if d.get("model_name") == model]
            if len(model_uids) > 0:
                model_uid = model_uids[0]
            else:
                raise InvokeBadRequestError(f"please check model {model} uid config")

        try:
            api_key = credentials.get("api_key")
            auth_headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
            
            model_support_voice = [
                x.get("value") for x in self.get_tts_model_voices(model=model, credentials=credentials)
            ]
            if not voice or voice not in model_support_voice:
                voice = self._get_model_default_voice(model, credentials)
            word_limit = self._get_model_word_limit(model, credentials)

            # Handle MegaTTS3 model with direct HTTP requests
            if "MegaTTS3" in str(model):
                result = self._handle_megatts3_request(
                    model_uid=model_uid,
                    credentials=credentials,
                    content_text=content_text,
                    voice=voice,
                    word_limit=word_limit,
                    auth_headers=auth_headers
                )
                # Temporarily force execution to see what happens
                try:
                    for chunk in result:
                        yield chunk
                except Exception as e:
                    raise
                return
            
            # Handle other models with standard xinference client
            handle = RESTfulAudioModelHandle(model_uid, credentials["server_url"], auth_headers=auth_headers)

            # Setup speech parameters based on model
            speech_params = {
                "input": "",
                "response_format": "mp3",
                "speed": 1.0,
                "stream": stream,
                "voice": voice,
            }

            if len(content_text) > word_limit:
                sentences = self._split_text_into_sentences(content_text, max_length=word_limit)
                executor = concurrent.futures.ThreadPoolExecutor(max_workers=min(3, len(sentences)))
                futures = [
                    executor.submit(
                        handle.speech,
                        **{**speech_params, "input": sentences[i]}
                    )
                    for i in range(len(sentences))
                ]

                if stream:
                    for future in futures:
                        response = future.result()
                        for chunk in response:
                            yield chunk
                else:
                    # In non-stream mode, directly merge bytes data
                    data = b"".join(future.result() for future in futures)
                    yield data
            else:
                speech_params["input"] = content_text.strip()
                response = handle.speech(**speech_params)
                if stream:
                    for chunk in response:
                        yield chunk
                else:
                    # In non-stream mode, ensure bytes type output
                    if isinstance(response, bytes):
                        yield response
                    else:
                        yield bytes(response)
        except Exception as ex:
            raise InvokeBadRequestError(str(ex))

    def _handle_megatts3_request(
        self, model_uid: str, credentials: dict, content_text: str, voice: str, word_limit: int, auth_headers: dict
    ) -> Any:
        """
        Handle MegaTTS3 model requests with direct HTTP calls to support binary data
        """
        try:
            # Get prompt data
            prompt_speech = self._get_tts_model_prompt_data(
                model="MegaTTS3", credentials=credentials, path_key='prompt_speech_path', voice=voice
            )
            prompt_latent = self._get_tts_model_prompt_data(
                model="MegaTTS3", credentials=credentials, path_key='prompt_latent_path', voice=voice
            )
            
            # Prepare multipart form data
            files = {}
            data = {
                "model": model_uid,
                "input": content_text.strip(),
                "response_format": "mp3",
                "speed": 1.0,
                "stream": False,
            }
            
            if prompt_speech:
                files["prompt_speech"] = ("prompt_speech.wav", prompt_speech, "audio/wav")
            if prompt_latent:
                files["prompt_latent"] = ("prompt_latent.npy", prompt_latent, "application/octet-stream")
            
            # Make direct HTTP request
            url = f"{credentials['server_url']}/v1/audio/speech"
            headers = auth_headers.copy()
            
            if len(content_text) > word_limit:
                sentences = self._split_text_into_sentences(content_text, max_length=word_limit)
                all_audio_data = b""
                
                for sentence in sentences:
                    sentence_data = data.copy()
                    sentence_data["input"] = sentence.strip()
                    sentence_data["model"] = model_uid
                    
                    response = requests.post(url, headers=headers, data=sentence_data, files=files)
                    if response.status_code != 200:
                        raise InvokeBadRequestError(f"HTTP {response.status_code}: {response.text}")
                    
                    all_audio_data += response.content
                
                yield all_audio_data
            else:
                response = requests.post(url, headers=headers, data=data, files=files)
                if response.status_code != 200:
                    raise InvokeBadRequestError(f"HTTP {response.status_code}: {response.text}")

                yield response.content
                
        except Exception as ex:
            raise InvokeBadRequestError(f"MegaTTS3 request failed: {str(ex)}")
