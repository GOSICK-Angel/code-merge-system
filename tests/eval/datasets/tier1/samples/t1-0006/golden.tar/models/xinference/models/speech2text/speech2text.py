from typing import IO, Optional
import concurrent.futures
import logging
import mimetypes
import time
import click
import numpy as np
from pydub import AudioSegment
from scipy.signal import stft
from io import BytesIO
from dify_plugin.entities.model import AIModelEntity, FetchFrom, I18nObject, ModelType
from dify_plugin.errors.model import (
    CredentialsValidateFailedError,
    InvokeAuthorizationError,
    InvokeBadRequestError,
    InvokeConnectionError,
    InvokeError,
    InvokeRateLimitError,
    InvokeServerUnavailableError,
)
from dify_plugin import Speech2TextModel
from xinference_client.client.restful.restful_client import Client, RESTfulAudioModelHandle
from models.xinference_helper import validate_model_uid

logger = logging.getLogger(__name__)


class XinferenceSpeech2TextModel(Speech2TextModel):
    """
    Model class for Xinference speech to text model.
    """

    def _invoke(self, model: str, credentials: dict, file: IO[bytes], user: Optional[str] = None,word_timestamps: Optional[bool] = False) -> str:
        """
        Invoke speech2text model

        :param model: model name
        :param credentials: model credentials
        :param file: audio file
        :param user: unique user id
        :return: text for given audio file
        """
        audio_type = mimetypes.guess_type(file.name)[0]
        num_threads = credentials.get("num_threads", 1)
        mini_silence_len = credentials.get("mini_silence_len", 0)
        if not audio_type:
            return self._speech2text_invoke(
                model=model,
                credentials=credentials,
                file=file,
                word_timestamps=word_timestamps,
            )
        else:
            return self._speech2text_multithread(
                model=model,
                credentials=credentials,
                file=file,
                num_threads=num_threads,
                word_timestamps=word_timestamps,
                min_silence_len=mini_silence_len,
            )
        
    def validate_credentials(self, model: str, credentials: dict, word_timestamps: Optional[bool] = False) -> None:
        """
        Validate model credentials

        :param word_timestamps:
        :param model: model name
        :param credentials: model credentials
        :return:
        """
        try:
            if not validate_model_uid(credentials):
                raise CredentialsValidateFailedError("model_uid should not contain /, ?, or #")

            credentials["server_url"] = credentials["server_url"].removesuffix("/")
            if "model_uid" in credentials:
                model_uid = credentials["model_uid"]
            else:
                model_uids = [d.get("model_uid") for d in credentials.get("models") if d.get("model_name") == model]
                if len(model_uids) > 0:
                    model_uid = model_uids[0]
                else:
                    raise InvokeBadRequestError(f"please check model {model} uid config")

            # initialize client
            client = Client(base_url=credentials["server_url"], api_key=credentials.get("api_key"))
            modelHandle = client.get_model(model_uid=str(model_uid))

            if not isinstance(modelHandle, RESTfulAudioModelHandle):
                raise InvokeBadRequestError(
                    "please check model type, the model you want to invoke is not a audio model"
                )

            audio_file_path = self._get_demo_file_path()

            with open(audio_file_path, "rb") as audio_file:
                self.invoke(model=model, credentials=credentials, file=audio_file, word_timestamps=word_timestamps)
        except Exception as ex:
            raise CredentialsValidateFailedError(str(ex))

    def _speech2text_multithread(
        self,
        model: str,
        word_timestamps: bool,
        credentials: dict,
        file: IO[bytes],
        num_threads: int,
        min_silence_len: int,
    ) -> str:
        try:
            audio_type = mimetypes.guess_type(file.name)[0]
            if audio_type:
                chunks = self._split_audio(file=file, audio_type=audio_type, min_silence_len=min_silence_len)
            else:
                return self._speech2text_invoke(
                    model=model,
                    credentials=credentials,
                    file=file,
                    word_timestamps=word_timestamps,
                )
            results = []
            start = time.perf_counter()
            with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
                future_to_chunk = {
                    executor.submit(
                        self._process_chunk,
                        chunk=chunk,
                        model=model,
                        word_timestamps=word_timestamps,
                        credentials=credentials,
                    ): i
                    for i, chunk in enumerate(chunks)
                }

                for future in concurrent.futures.as_completed(future_to_chunk):
                    index = future_to_chunk[future]
                    try:
                        result = future.result()
                        results.append((index, result))
                    except Exception as ex:
                        logger.exception(f"Failed to process chunk {index}. Reason: {str(ex)}")
                        raise InvokeBadRequestError(str(ex))

            # Sort results by index and concatenate them
            results.sort(key=lambda x: x[0])
            final_result = "\n".join([res[1] for res in results])
            end = time.perf_counter()
            elapsed_time = float(f"{end - start:0.4f}")
            logging.info(click.style(f"It takes {elapsed_time}s to Audio to txt", fg="green"))
            return final_result

        except Exception as ex:
            logger.exception(f"Failed to invoke speech2text model in multithreaded mode. Reason: {str(ex)}")
            raise InvokeBadRequestError(str(ex))

    @property
    def _invoke_error_mapping(self) -> dict[type[InvokeError], list[type[Exception]]]:
        """
        Map model invoke error to unified error
        The key is the error type thrown to the caller
        The value is the error type thrown by the model,
        which needs to be converted into a unified error type for the caller.

        :return: Invoke error mapping
        """
        return {
            InvokeConnectionError: [InvokeConnectionError],
            InvokeServerUnavailableError: [InvokeServerUnavailableError],
            InvokeRateLimitError: [InvokeRateLimitError],
            InvokeAuthorizationError: [InvokeAuthorizationError],
            InvokeBadRequestError: [InvokeBadRequestError, KeyError, ValueError],
        }

    def _speech2text_invoke(
        self,
        model: str,
        credentials: dict,
        file: IO[bytes],
        language: Optional[str] = None,
        prompt: Optional[str] = None,
        response_format: Optional[str] = "json",
        temperature: Optional[float] = 0,
        word_timestamps: Optional[bool] = False,
    ) -> str:
        """
        Invoke speech2text model

        :param model: model name
        :param credentials: model credentials
        :param file: The audio file object (not file name) to transcribe, in one of these formats: flac, mp3, mp4, mpeg,
          mpga, m4a, ogg, wav, or webm.
        :param language: The language of the input audio. Supplying the input language in ISO-639-1
        :param prompt: An optional text to guide the model's style or continue a previous audio segment.
            The prompt should match the audio language.
        :param response_format: The format of the transcript output, in one of these options: json, text, srt,
          verbose_json, or vtt.
        :param temperature: The sampling temperature, between 0 and 1. Higher values like 0.8 will make the output more
          random,while lower values like 0.2 will make it more focused and deterministic.If set to 0, the model will use
          log probability to automatically increase the temperature until certain thresholds are hit.
        granularities: Optional[List[str]], default is None.
            The granularities to populate for this transcription. response_format must be set verbose_json
            to use  granularities. Either or both of these options are supported: word, or segment.
        :return: text for given audio file
        """
        api_key = credentials.get("api_key")
        credentials["server_url"] = credentials["server_url"].removesuffix("/")
        if "model_uid" in credentials:
            model_uid = credentials["model_uid"]
        else:
            model_uids = [d.get("model_uid") for d in credentials.get("models") if d.get("model_name") == model]
            if len(model_uids) > 0:
                model_uid = model_uids[0]
            else:
                raise InvokeBadRequestError(f"please check model {model} uid config")

        try:
            handle = RESTfulAudioModelHandle(
                model_uid=model_uid,
                base_url=credentials["server_url"],
                auth_headers={"Authorization": f"Bearer {api_key}"} if api_key else {},
            )
            file_bytes = file.read()
            if model.find("whisper") != -1:
                response = handle.transcriptions(
                    audio=file_bytes,
                    language=language or "zh",
                    prompt=prompt,
                    response_format="verbose_json" if word_timestamps else response_format,
                    temperature=temperature,
                    timestamp_granularities=["segment"],
                )
                if word_timestamps:
                    return self._verbose_json_to_srt(json_data=response["segments"])
            else:
                response = handle.transcriptions(
                    audio=file_bytes,
                    language=language or "zh",
                    prompt=prompt,
                    temperature=temperature,
                )
            return response["text"]
        except RuntimeError as e:
            raise InvokeServerUnavailableError(str(e))

    def get_customizable_model_schema(self, model: str, credentials: dict) -> Optional[AIModelEntity]:
        """
        used to define customizable model schema
        """
        entity = AIModelEntity(
            model=model,
            label=I18nObject(en_US=model),
            fetch_from=FetchFrom.CUSTOMIZABLE_MODEL,
            model_type=ModelType.SPEECH2TEXT,
            model_properties={},
            parameter_rules=[],
        )
        return entity


    def _split_audio(
        self, file: IO[bytes], audio_type: str, min_silence_len: Optional[int] = 2000
    ) -> list[bytes]:
        """
        Split the audio according to the speaker's pause time or channel changes.

        :param file: audio file
        :param audio_type: audio type
        :param min_silence_len: Minimum pause time in milliseconds for mono files, default is 2000 milliseconds (2 seconds)
        :return: List of segmented audio clips
        """
        audio = None  # Initialize early
        try:
            if audio_type == "audio/x-wav":
                audio = AudioSegment.from_wav(file)
            elif audio_type == "audio/mpeg":
                audio = AudioSegment.from_file(file, format="mp3")
            elif audio_type in ["audio/mp4a-latm", "audio/x-m4a", "audio/mp4"]:
                audio = AudioSegment.from_file(file, format="m4a")
            else:
                audio = AudioSegment.from_file(file, format=audio_type.split("/")[1])

            # Set frame rate for processing consistency
            audio = audio.set_frame_rate(16000)

            # Check the number of channels in the input file
            num_channels = audio.channels

            if num_channels > 1:
                return self._split_multi_channel_by_frequency_change(audio)
            else:
                return self._split_audio_by_silence(audio, min_silence_len)
        except Exception as e:
            logging.exception(f"Error in audio splitting: {str(e)}")
            if audio is not None:
                return [audio]
            else:
                file.seek(0)
                try:
                    audio = AudioSegment.from_file(file, format="m4a")
                    audio = audio.set_frame_rate(16000)
                    return [audio]
                except Exception as inner_e:
                    logging.exception(f"Fallback audio reading failed: {str(inner_e)}")
                    raise InvokeBadRequestError(f"Audio splitting failed: {str(e)}")

    def _split_multi_channel_by_frequency_change(self, audio: AudioSegment) -> list[AudioSegment]:
        """
        Split multi-channel audio based on frequency analysis to detect speaker changes.
        Supports any number of channels (>=2).

        :param audio: The multi-channel audio segment.
        :return: List of segmented audio clips.
        """
        try:
            start = time.perf_counter()
            # Get all channel data
            channels = audio.split_to_mono()
            num_channels = len(channels)
            t = 0

            if num_channels < 2:
                logger.warning("Audio has less than 2 channels, falling back to silence-based splitting")
                return self._split_audio_by_silence(audio)

            # Convert each channel to a numpy array and calculate the STFT
            channel_stfts = []
            for channel in channels:
                samples = np.array(channel.get_array_of_samples())
                _, t, Zxx = stft(
                    samples,
                    fs=audio.frame_rate,
                    nperseg=2048,  # Increase the window size for better frequency resolution
                    noverlap=1024,
                )  # 50% overlap
                channel_stfts.append(Zxx)

            # Calculate the spectral difference between all channel pairs
            spectral_diffs = []
            for i in range(num_channels):
                for j in range(i + 1, num_channels):
                    diff = np.abs(np.sum(np.abs(channel_stfts[i]), axis=0) - np.sum(np.abs(channel_stfts[j]), axis=0))
                    spectral_diffs.append(diff)

            # Merge all differences
            combined_diff = np.max(spectral_diffs, axis=0)

            # Use adaptive thresholds
            threshold = np.mean(combined_diff) + 2 * np.std(combined_diff)

            # Identify significant changes
            segments = []
            current_start_time = 0
            min_segment_length = 1000  # Minimum segment length (milliseconds)

            for i in range(1, len(t)):
                current_time = int(t[i] * 1000)  # Convert to milliseconds

                if combined_diff[i] > threshold and (current_time - current_start_time) >= min_segment_length:
                    # Add new fragment
                    segments.append(audio[current_start_time:current_time])
                    current_start_time = current_time

            # Add the last fragment
            if current_start_time < len(audio):
                segments.append(audio[current_start_time:])

            # Merge short fragments
            merged_segments = self._merge_short_segments(segments, min_length_ms=1000)

            end = time.perf_counter()
            elapsed_time = float(f"{end - start:0.4f}")
            logging.info(click.style(f"It takes {elapsed_time}s to Multichannel audio speaker cutting", fg="green"))

            return merged_segments
        except Exception as e:
            logging.exception(f"Error in multi-channel frequency analysis: {str(e)}")
            # Fall back to the silent-based split when an error occurs
            return self._split_audio_by_silence(audio)

    def _split_audio_by_silence(self, audio: AudioSegment, min_silence_len: int = 2000) -> list[AudioSegment]:
        """
        Silence-based audio segmentation method (as a backup)

        :param audio: Audio clip
        :param min_silence_len: Minimum silence length (milliseconds)
        :return: List of segmented audio clips
        """
        start = time.perf_counter()
        nonsilent_ranges = self._detect_nonsilent(
            audio_segment=audio, min_silence_len=min_silence_len, silence_thresh=-50, seek_step=100
        )
        # merged_segments = [audio[start:end] for start, end in nonsilent_ranges]
        merged_segments = [audio[max(0, start) : min(end, len(audio))] for start, end in nonsilent_ranges]

        # Filter out empty fragments
        merged_segments = [seg for seg in merged_segments if len(seg) > 0]
        end = time.perf_counter()
        elapsed_time = float(f"{end - start:0.4f}")
        logging.info(
            click.style(
                f"It takes {elapsed_time}s to mute mono audio split into {len(merged_segments)} subsegments", fg="green"
            )
        )

        return merged_segments or [audio]

    def _detect_nonsilent(
        self, audio_segment: AudioSegment, min_silence_len: int = 2000, silence_thresh: int = -50, seek_step: int = 100
    ) -> list[tuple[int, int]]:
        """
        Optimized version of silence detection

        :param audio_segment: Audio segment to process
        :param min_silence_len: Minimum length of silence in ms
        :param silence_thresh: Silence threshold in dB
        :param seek_step: Step size for seeking through audio in ms
        :return: List of (start_ms, end_ms) ranges of non-silent audio
        """
        try:
            # Convert audio to numpy arrays for faster processing
            samples = np.array(audio_segment.get_array_of_samples(), dtype=np.float32)

            # Make sure the samples are not empty
            if len(samples) == 0:
                logger.warning("Empty audio samples detected")
                return [(0, len(audio_segment))]

            # Calculate the RMS value for each seek_step
            chunk_length = int(audio_segment.frame_rate * (seek_step / 1000.0))
            chunk_length = max(1, chunk_length)

            # Counting chunks
            chunks_cnt = max(1, int(len(samples) / chunk_length))

            # Calculate the RMS value using vectorization operations
            chunks = samples[: chunks_cnt * chunk_length].reshape((-1, chunk_length))
            eps = np.finfo(np.float32).eps
            chunks = chunks + eps

            # Use secure RMS calculations
            rms = np.sqrt(np.maximum(np.mean(chunks * chunks, axis=1), 0))

            # Convert to dB
            max_possible_amplitude = float(audio_segment.max_possible_amplitude) or 1.0
            rms = np.maximum(rms, eps)
            db = 20 * np.log10(rms / max_possible_amplitude)

            # Find the unsilent part
            nonsilent = db > silence_thresh

            # If no unmuted parts are detected, return the entire audio range
            if not np.any(nonsilent):
                logger.warning("No non-silent parts detected, returning full range")
                return [(0, len(audio_segment))]

            # Merge short silent sections
            min_silence_chunks = int(min_silence_len / seek_step)
            nonsilent = self._merge_short_silence(nonsilent, min_silence_chunks)

            # Convert to timestamp
            ranges = []
            current_start = None

            for i, is_nonsilent in enumerate(nonsilent):
                if is_nonsilent and current_start is None:
                    current_start = i
                elif not is_nonsilent and current_start is not None:
                    ranges.append((int(current_start * seek_step), int(i * seek_step)))
                    current_start = None

            # Process the last unsilent segment
            if current_start is not None:
                ranges.append((int(current_start * seek_step), len(audio_segment)))

            # If no range is detected, return the entire audio
            if not ranges:
                logger.warning("No ranges detected, returning full range")
                return [(0, len(audio_segment))]

            return ranges
        except Exception as e:
            logger.exception(f"Error in detect_nonsilent: {str(e)}")
            return [(0, len(audio_segment))]

    def _process_chunk(self, chunk: AudioSegment, model: str, word_timestamps: bool, credentials: dict) -> str:
        # Convert AudioSegment to bytes-like object for processing each time it's called.
        file_like_object = BytesIO()

        # Export the chunk to a bytes-like object with appropriate parameters.
        try:
            chunk.export(file_like_object, format="mp3", codec="libmp3lame")  # Ensure using correct codec.
            file_like_object.seek(0)

            # Log the size of the exported data.
            logger.info(f"Exported chunk size:{file_like_object.getbuffer().nbytes} bytes")

            if file_like_object.getbuffer().nbytes == 0:
                raise ValueError("Exported file is empty.")

            return self._speech2text_invoke(
                model=model, word_timestamps=word_timestamps, credentials=credentials, file=file_like_object
            )

        except Exception as ex:
            logger.exception(f"Failed to export and process chunk.Reason:{str(ex)}")
            raise InvokeBadRequestError(str(ex))

    def get_customizable_model_schema(self, model: str, credentials: dict) -> Optional[AIModelEntity]:
        """
        used to define customizable model schema
        """
        entity = AIModelEntity(
            model=model,
            label=I18nObject(en_US=model),
            fetch_from=FetchFrom.CUSTOMIZABLE_MODEL,
            model_type=ModelType.SPEECH2TEXT,
            model_properties={},
            parameter_rules=[],
        )

        return entity

    @staticmethod
    def _format_time(seconds):
        """Convert seconds to SRT time format hh:mm:ss,ms"""
        milliseconds = int((seconds - int(seconds)) * 1000)
        seconds = int(seconds)
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        seconds = seconds % 60
        return f"{hours:02}:{minutes:02}:{seconds:02},{milliseconds:03}"

    @staticmethod
    def _merge_short_segments(segments: list[AudioSegment], min_length_ms: int = 1000) -> list[AudioSegment]:
        """
        Merge short audio clips

        :param segments: List of audio clips
        :param min_length_ms: Minimum segment length (milliseconds)
        :return: List of combined audio clips
        """
        if not segments:
            return segments

        merged = []
        current_segment = segments[0]

        for next_segment in segments[1:]:
            if len(current_segment) < min_length_ms:
                # If the current fragment is too short, merge with the next fragment
                current_segment = current_segment + next_segment
            else:
                merged.append(current_segment)
                current_segment = next_segment

        # Add the last fragment
        merged.append(current_segment)
        return merged

    @staticmethod
    def _merge_short_silence(nonsilent: np.ndarray, min_silence_chunks: int) -> np.ndarray:
        """
        Merge short silent sections

        :param nonsilent: Boolean array, indicating whether each sample is unmuted
        :param min_silence_chunks: Minimum number of silent samples
        :return: The processed Boolean array
        """
        if min_silence_chunks <= 1:
            return nonsilent

        # Use convolution to find short silent segments
        kernel = np.ones(min(len(nonsilent), min_silence_chunks))
        conv = np.convolve(nonsilent.astype(float), kernel, mode="same")

        # If there are any unmuted samples within the min_silence_samples range, the entire range is considered unmuted
        return conv > 0

    def _verbose_json_to_srt(self, json_data: list):
        """Convert JSON subtitles to SRT format"""
        srt_content = []

        for index, item in enumerate(json_data, start=1):
            start_time = self._format_time(item["start"])
            end_time = self._format_time(item["end"])
            text = item["text"]

            srt_content.append(f"{index}")
            srt_content.append(f"{start_time} --> {end_time}")
            srt_content.append(text)
            srt_content.append("")  # Blank line between subtitles

        return "\n".join(srt_content)
