# 搜索会议工具
# 此文件从原 pub-dify/api/core/tools/provider/builtin/maxhub/tools/search_meeting.py 迁移
# 主要修改：
# 1. 导入路径改为 dify_plugin.*
# 2. 简化用户信息获取逻辑
# 3. 移除数据库直接访问，改为API调用

from datetime import datetime, timedelta
from typing import Any, Dict, List, Generator

import pytz
from dify_plugin.entities.tool import ToolInvokeMessage
from dify_plugin.errors.tool import ToolProviderCredentialValidationError
from dify_plugin.interfaces.tool import Tool

from provider.maxhub import MAXHUBProvider
from .meeting_public_class import TimeValidationHelper, requests_retry_session


class ToolInvokeError(Exception):
    """工具调用错误"""
    pass


class ToolParameterValidationError(Exception):
    """工具参数验证错误"""
    pass


class MAXHUBMeetingSearchTool(Tool):
    def _invoke(
        self, tool_parameters: dict[str, Any]
    ) -> Generator[ToolInvokeMessage, None, None]:
        """
        搜索会议工具，查找指定时间范围内的会议

        Args:
            tool_parameters: 工具参数字典，包含以下可选参数:
                - meeting_start_time: 会议开始时间，格式为YYYY-MM-DD HH:MM，默认为当前时间
                - meeting_end_time: 会议结束时间，格式为YYYY-MM-DD HH:MM，默认为开始时间后10天
                - meeting_room: 会议室名称，用于过滤结果
                - industrial_park: 产业园区名称，用于过滤结果
                - subject: 会议主题关键词，用于过滤结果

        Returns:
            ToolInvokeMessage: 包含查询结果的文本消息

        Raises:
            ToolProviderCredentialValidationError: 凭据验证失败时抛出
            ToolParameterValidationError: 参数验证失败时抛出
            ToolInvokeError: 会议查询失败时抛出
        """
        self._validate_credentials()
        user_email = tool_parameters.get("user_email")

        if not user_email:
            yield self.create_text_message("邮箱不能为空")
            return

        tz_str = tool_parameters.get("timezone", "Asia/Shanghai")
        try:
            tz = pytz.timezone(tz_str)
        except pytz.exceptions.UnknownTimeZoneError:
            raise ToolParameterValidationError(f"Invalid timezone: {tz_str}")

        try:
            api_domain = self.runtime.credentials.get("api_domain")
            org_code = self.runtime.credentials.get("org_code")
            api_version = self.runtime.credentials.get("api_version")
            company_code = self.runtime.credentials.get("company_id")
            
            if not api_domain or not company_code:
                raise ToolParameterValidationError("Missing required credentials")
                
            headers = MAXHUBProvider.get_headers_credentials(self.runtime.credentials)
            start_time, end_time = self._parse_time_parameters(tz, tool_parameters)
            my_meetings = self._fetch_meetings(
                api_domain, headers, company_code, user_email, start_time, end_time
            )
            own_meeting = tool_parameters.get("own_meeting")
            meeting_room = tool_parameters.get("meeting_room")

            if meeting_room and not own_meeting:
                meeting_conflictings = self._conflicting_meeting_query(
                    api_domain=api_domain,
                    api_version=api_version,
                    org_code=org_code,
                    headers=headers,
                    start_time=start_time,
                    end_time=end_time,
                    industrial_park=tool_parameters.get("industrial_park"),
                    meeting_room=meeting_room,
                    tz=tz,
                )
                if meeting_conflictings:
                    yield self.create_text_message(
                        f"No record of your meeting appointment was found during this period, "
                        f"but initiating an appointment would conflict with the following meeting:"
                        f"\n{meeting_conflictings}"
                    )

            if not my_meetings:
                yield self.create_text_message("You don't have any meetings scheduled during this period.")
                return

            owner_meetings_final, attend_meetings_final = self._classify_meetings(
                my_meetings,
                api_domain,
                api_path_prefix=f"/meeting/api/open/{api_version}/meetings",
                headers=headers,
                user_email=user_email,
            )

            if len(owner_meetings_final) == 0 and len(attend_meetings_final) == 0:
                yield self.create_text_message(
                    "During this time period, you will not schedule any meetings as creator or participant"
                )
                return

            return_sentences = ""

            filtered_owner_meetings = self._filter_meetings(owner_meetings_final, tool_parameters)
            if filtered_owner_meetings:
                unique_owner_meetings = self._deduplicate_meetings(filtered_owner_meetings)
                if unique_owner_meetings:
                    return_sentences += self._format_meetings(
                        tz,
                        unique_owner_meetings,
                        "Below are the minutes of the meeting you initiated：\n\n",
                    )

            filtered_attend_meetings = self._filter_meetings(attend_meetings_final, tool_parameters)
            if filtered_attend_meetings:
                unique_attend_meetings = self._deduplicate_meetings(filtered_attend_meetings)
                if unique_attend_meetings:
                    return_sentences += self._format_meetings(
                        tz,
                        unique_attend_meetings,
                        "Below are the minutes of the meetings you attended：\n\n",
                    )

            # 如果有会议数据，输出格式化结果
            if return_sentences:
                yield self.create_text_message(return_sentences)

        except ToolParameterValidationError:
            raise
        except Exception as e:
            raise ToolInvokeError(str(e))

    def _validate_credentials(self) -> None:
        """验证凭据完整性"""
        required_fields = {
            "api_domain": "MAXHUB API Domain is required.",
            "company_id": "MAXHUB Company Code is required.",
            "api_version": "MAXHUB API Version is required.",
        }

        for field, error_msg in required_fields.items():
            if field not in self.runtime.credentials or not self.runtime.credentials.get(field):
                raise ToolProviderCredentialValidationError(error_msg)

    @staticmethod
    def _parse_time_parameters(tz: Any, tool_parameters: Dict[str, Any]) -> tuple[int, int]:
        """解析时间参数"""
        now = datetime.now(tz)

        validation_result = TimeValidationHelper.validate_meeting_parameters(
            tool_parameters=tool_parameters,
            current_time=now
        )
        
        if not validation_result["success"]:
            raise ToolParameterValidationError(validation_result["message"])

        start_time_str = tool_parameters.get("start_time")
        if start_time_str and "start_time" in validation_result["validated_params"]:
            start_time = int(validation_result["validated_params"]["start_time"].timestamp() * 1000)
        else:
            start_time = int(now.timestamp() * 1000)

        end_time_str = tool_parameters.get("end_time")
        if end_time_str:
            if "end_time" in validation_result["validated_params"]:
                end_time = int(validation_result["validated_params"]["end_time"].timestamp() * 1000)
            else:
                try:
                    end_time_validation = TimeValidationHelper.validate_absolute_time(
                        time_str=end_time_str,
                        current_time=now,
                        check_expired=True,
                    )
                    if not end_time_validation["success"]:
                        raise ToolParameterValidationError(end_time_validation["message"])
                except Exception as e:
                    raise ToolParameterValidationError(f"Invalid end time: {str(e)}")
                end_time = int(end_time_validation["time"].timestamp() * 1000)
        else:
            future = now + timedelta(days=10)
            end_time = int(future.timestamp() * 1000)

        return start_time, end_time

    @staticmethod
    def _fetch_meetings(
        api_domain: str, headers: Dict, company_code: str, email: str, start_time: int, end_time: int
    ) -> List[Dict]:
        """获取基础会议列表"""
        room_response = requests_retry_session().request(
            method="GET",
            headers=headers,
            verify=True,
            url=f"{api_domain}/meeting/api/v1/client/meetings"
            f"?company_code={company_code}&email={email}&page_no=1&page_size=100"
            f"&start_time={start_time}&end_time={end_time}",
        )

        if room_response.status_code != 200:
            error_msg = room_response.text if hasattr(room_response, "text") else "Unknown error"
            raise ToolInvokeError(f"Failed to obtain a meeting：{error_msg}")

        response_data = room_response.json()
        return [d for d in response_data.get("meetings", []) if d and d.get("status") == 1]

    def _classify_meetings(
        self,
        meetings: List[Dict],
        api_domain: str,
        api_path_prefix: str,
        headers: Dict,
        user_email: str,
    ) -> tuple[List[Dict], List[Dict]]:
        """获取会议详细信息并按创建者分类"""
        owner_meetings = []
        attend_meetings = []

        for meeting in meetings:
            meeting_no = meeting.get("meeting_no")
            if not meeting_no:
                continue

            # 尝试获取会议详细信息
            meeting_data = None
            try:
                api_path = f"{api_path_prefix}/{meeting_no}"
                updated_headers = MAXHUBProvider.update_auth_headers(
                    headers=headers.copy(), credentials=self.runtime.credentials, http_method="GET", api_path=api_path
                )
                meeting_response = requests_retry_session().request(
                    method="GET", headers=updated_headers, verify=True, url=f"{api_domain}{api_path}"
                )

                if meeting_response.status_code == 200:
                    meeting_data = meeting_response.json().get("data", {})
            except Exception:
                # 如果获取详情失败，使用基本会议数据
                pass

            # 如果无法获取详细信息，使用列表API返回的基本数据
            if not meeting_data:
                meeting_data = meeting

            # 判断是否为创建者
            creator = meeting_data.get("creator", {})
            is_creator = False
            if creator.get("email") and user_email and creator["email"] == user_email:
                is_creator = True

            if is_creator:
                owner_meetings.append(meeting_data)
            else:
                attend_meetings.append(meeting_data)

        return owner_meetings, attend_meetings

    @staticmethod
    def _filter_meetings(meetings: List[Dict], filter_params: Dict[str, Any]) -> List[Dict]:
        """根据参数过滤会议"""
        filtered_meetings = meetings

        room_number = filter_params.get("meeting_room")
        industrial_park = filter_params.get("industrial_park")
        subject = filter_params.get("subject")

        if room_number:
            filtered_meetings = [m for m in filtered_meetings if m.get("address") and room_number in m["address"]]
        if industrial_park:
            filtered_meetings = [m for m in filtered_meetings if m.get("address") and industrial_park in m["address"]]
        if subject:
            filtered_meetings = [m for m in filtered_meetings if m.get("theme") and subject in m["theme"]]

        return filtered_meetings

    @staticmethod
    def _deduplicate_meetings(meetings: List[Dict]) -> List[Dict]:
        """去除重复会议"""
        unique_meetings = []
        meeting_ids = set()

        for meeting in meetings:
            meeting_no = meeting.get("meeting_no")
            if meeting_no and meeting_no not in meeting_ids:
                meeting_ids.add(meeting_no)
                unique_meetings.append(meeting)

        return unique_meetings

    @staticmethod
    def _format_meetings(tz: Any, meetings: List[Dict], header: str) -> str:
        """格式化会议信息"""
        if not meetings:
            return ""

        formatted_lines = [header]
        
        for meeting in meetings:
            meeting_no = meeting.get("meeting_no", "Unknown")
            theme = meeting.get("theme", "No theme")
            address = meeting.get("address", "No location")
            members=meeting.get("members", "No members")
            
            # 格式化时间
            start_time = meeting.get("start_time")
            end_time = meeting.get("end_time")
            
            if start_time and end_time:
                try:
                    start_dt = datetime.fromtimestamp(start_time / 1000, tz=tz)
                    end_dt = datetime.fromtimestamp(end_time / 1000, tz=tz)
                    time_str = f"{start_dt.strftime('%Y-%m-%d %H:%M')} - {end_dt.strftime('%H:%M')}"
                except (ValueError, TypeError):
                    time_str = "Time unknown"
            else:
                time_str = "Time unknown"
            
            formatted_lines.append(f"• [{meeting_no}] {theme}")
            formatted_lines.append(f"  Time: {time_str}")
            formatted_lines.append(f"  Location: {address}")
            formatted_lines.append(f"  Members: {members}")
            formatted_lines.append("")

        return "\n".join(formatted_lines)

    def _conflicting_meeting_query(
        self,
        api_domain,
        headers,
        org_code,
        meeting_room,
        industrial_park,
        start_time,
        end_time,
        api_version,
        tz: Any,
    ) -> str:
        """查询会议室冲突"""
        api_path = f"/taro/api/open/v3/page/space?orgCode={org_code}&keyword={meeting_room}&pageSize=100"

        room_headers = MAXHUBProvider.update_auth_headers(
            headers=headers.copy(), credentials=self.runtime.credentials, http_method="GET", api_path=api_path
        )

        room_response = requests_retry_session().request(
            method="GET", headers=room_headers, verify=True, url=f"{api_domain}{api_path}"
        )

        if room_response.status_code != 200:
            raise ToolInvokeError(f"Failed to retrieve meeting rooms: {room_response.text}")

        room_data = room_response.json()
        if not room_data.get("success"):
            error_message = room_data.get("message", "Unknown error")
            raise ToolInvokeError(f"Failed to retrieve meeting rooms: {error_message}")

        meeting_rooms = []
        if room_data.get("data") and room_data["data"].get("data"):
            if not industrial_park:
                meeting_rooms = [
                    d for d in room_data["data"]["data"] if d.get("buildingName")
                ]
            else:
                meeting_rooms = [
                    d
                    for d in room_data["data"]["data"]
                    if d.get("buildingName") and industrial_park.lower() in d.get("buildingName").lower()
                ]

        if not meeting_rooms:
            return ""

        # 查询每个会议室的冲突情况
        conflicting_meetings = []
        
        for room in meeting_rooms[:5]:  # 限制查询数量避免过多请求
            room_id = room.get("refId")
            if not room_id:
                continue
                
            # 这里应该查询具体会议室的预订情况
            # 具体实现需要根据MAXHUB API调整
            
        return ""  # 返回冲突信息，具体格式根据需要调整 